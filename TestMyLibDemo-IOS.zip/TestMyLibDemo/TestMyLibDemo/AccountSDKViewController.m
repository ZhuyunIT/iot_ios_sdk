//
//  ViewController.m
//  ZYIOTSdkDemo_2_2
//
//  Created by zy-cxm on 2019/06/25.
//  Copyright © 2019年 zy-cxm. All rights reserved.
//

#import "AccountSDKViewController.h"
#import "ZYAccountSDK.h"
#import "AboutZYEntity.h"
#import "ZYFotaApi.h"
#import "ZYAccountSDK.h"
#import "AFNetworkReachabilityManager.h"
#import "AppDelegate.h"


#import <SystemConfiguration/SCNetworkReachability.h>
#import <netdb.h>

#import <dlfcn.h>

@interface AccountSDKViewController ()<MyEventResponseDelegate, ZYDevUpdateDelegate,IOTOnlineDelegate,ZYIOTClientStateDelegate,ZYSDKLoginDelegate,UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextView *tvLogs;//显示打印记录

@property (weak, nonatomic) IBOutlet UITextField *edtTenantId;//tenantId，筑云提供的特定的值
@property (weak, nonatomic) IBOutlet UITextField *edtAccount;//user account phone/email
@property (weak, nonatomic) IBOutlet UITextField *edtAcPwd;//user account pwd

@property (weak, nonatomic) IBOutlet UITextField *edtDevTypeId;//设备类型ID

@property (strong, nonatomic) NSString *childDevKeyhash;//test子设备接口时用的keyhash
@property (weak, nonatomic) IBOutlet UITextField *edtTargetKeyhash;// 以下API用的dev keyhash
@property (weak, nonatomic) IBOutlet UITextField *edtEventAttrName;//设备属性名
@property (weak, nonatomic) IBOutlet UITextField *edtEventAttrType;//设备属性值类型
@property (weak, nonatomic) IBOutlet UITextField *edtEventValue;//设备属性值
@property (strong, nonatomic) NSString *zotToken;//SDK初始化后得到的zotToken
@property (strong,nonatomic) UIButton *doneButton;
@property int logsLineNumber;
@property (nonatomic,strong) NSMutableDictionary *valuesHexMap;//为了接收hex分片Event。<attrName+eventId,array<NSData>>
@property (strong,nonatomic) ZYAccountSDK *zySdk;
@property (strong,nonatomic) NSMutableDictionary *childOnlineDicInfo;//记录子设备是否登录在线，子设备在线发送event才会成功

@property (strong,nonatomic) NSString *devTypeId;//不同的设备可能会是不同的设备类型，一般一个厂家一个设备类型。
@property (strong, nonatomic) NSString *myPhoneKeyhash;//本机Keyhash


@property (strong) NSOperationQueue *queue;
@property (strong) NSTimer *timer;
@property (strong) NSTimer *timer2;
@property (strong,nonatomic)  AFNetworkReachabilityManager *manger ;
@end

@implementation AccountSDKViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appWillEnterForegroundNotification) name:UIApplicationWillEnterForegroundNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appDidEnterBackgroundNotification) name:UIApplicationDidEnterBackgroundNotification object:nil];
    __weak typeof(self) weakSelf=self;
    /**
     1、属性：根据设备类型由厂家规定，包含属性名、属性值类型。（属性规定，详见厂家设备属性定义文档）。
     2、Event是APP与设备进行通信的消息封装，包含设备属性名、属性值、属性值类型。
     3、ZYIOTSDK主要分为三块：FOTA、IOT、IOT、DNS。分别指代：FOTA设备固件升级模块；IOT设备通信的专用通道；ZOT用户与设备等的业务处理（除了FOTA与IOT之外的业务）；DNS是存储了不同APP版本的服务器DNS信息；
     4、本Demo只是使用SDK的示例，展示主要功能：登录、绑定设备、删除设备、控制设备、获取设备列表、获取设备所有属性、、分享设备(增加、编辑、删除分享)、设备固件升级功能。其他功能接口的介绍，详见API文档（ZYAccountSDK.h和ZYBaseSDK.h）
     5、SDK一定要先登录成功才能正常使用。
     6、本Demo运行正常前提：
     **（登录）启动SDK时填入已注册的筑云账号、密码，以及tanantId，点击“登录”（回调时返回码是200，SDK启动成功）；
     绑定设备时devTypeId和keyhash要正确（调用接口时记的将devTypeId改为自己厂家设备对应的devTypeId）。
     */
    
    //init sdk start
//    self.edtAccount.text=@"18850526607";
    //初始化：SDK一定要先登录成功才能正常使用。
    int your_tenantId=[_edtTenantId.text intValue];
    NSString *your_user_account=_edtAccount.text;//已注册筑云的手机号
    NSString *your_user_pwd=_edtAcPwd.text;
    self.zySdk=[ZYAccountSDK getZYAccountSDKInstance];
//    [self loginToInitSDKWithTenantd:your_tenantId phone:your_user_account password:your_user_pwd];
    BOOL isSDKLogin=[self.zySdk isSDKLogin] ;//SDK 登录状态获取
//            [[ZYFotaAPI getFotaInstance] setFotaDomain:@"zhuyun.f3322.net"];//设置Fota服务器地址
//        [[ZYFotaAPI getFotaInstance] setFotaPort:9324];//设置Fota端口号
    [self updateLogsText:[NSString stringWithFormat:@"now.DNSKey=%@",self.zySdk.getDNSKey]];
    [self.zySdk setHttpDNSServerDomain:@"zhuyun.f3322.net"];
    NSLog(@"your dnskey=%@",[self.zySdk getDNSKey]);
    // //DNSKey是由筑云分配给APP开发者的，请提前申请
    [self.zySdk setDNSKey:@"your DNSKey"];
//    [self.zySdk setDNSKey:@"5d0728741313f1bc384b9dbb"];
    //调用此接口前请先调用SDK接口setDNSKey,设置DNSKey之后才可以成功获取APP对应的服务器DNS信息
//    [self.zySdk getHttpDNSInfosWithCompletion:^(NSMutableArray *httpDNSInfos, int retcode, NSString *errDescription) {
//        //此处获取到了APP不同版本的服务器DNS信息
//        NSString *log=[NSString stringWithFormat:@"%d getHttpDNSInfo结果=%@,e=%@",retcode,httpDNSInfos,errDescription];
//    }];
   /* //获取筑云消息中心的消息类型列表
    [self.zySdk getMessageTypeListWithLanguage:@"zh" completion:^(NSMutableArray *msgTypes, int retcode, NSString *errDescription) {
        NSString *log=[NSString stringWithFormat:@"%d getMsgTypeList=%@,e=%@",retcode,msgTypes,errDescription];
        [weakSelf updateLogsText:log];
    }];
    //获取筑云消息中心的消息列表
    [self.zySdk getMessageListWithLanguage:@"en" timestamp:0 devTypeId:@"1" completion:^(NSMutableArray *msgs, NSMutableArray *deleteMsgs, int retcode, NSString *errDescription) {
        NSString *log=[NSString stringWithFormat:@"%d getMsgList=%@,deleteMsgs=%@,e=%@",retcode,msgs,deleteMsgs,errDescription];
        [weakSelf updateLogsText:log];
    }];*/
    //    默认的服务器有效，不需要修改也可以测试。IOT、ZOT、FOTA服务器域名指向有效，默认的服务器指向是有效的，可以不用改，（如果重新部署迁移服务器，需要重新set）
    [self.zySdk setZotDomain:@"zhuyun.f3322.net"];//ZOT模块服务器IP入口
    [self.zySdk setZotPort: 9390];
    [self.zySdk setIOTServer:@"zhuyun.f3322.net"];//IOT模块服务器多IP入口，多个时用英文分号隔开
    //设置IOT Client状态变化监听代理：可以得到IOT Client的状态。当状态值为1或3时可以正常发送Event与设备通信。
    [self.zySdk setIOTClientStateDelegate:self];
    
    //设置event发送与接收的结果监听代理。与设备进行通信时的消息封装是Event。实现这个代理可以实时监听设备状态变化。如APP可以收到在Event[online@zot=0](表示设备掉线)时刷新UI.
    [self.zySdk addZYEventResponseDelegate:self];
    
    //设置IOT Client在线与异常离线的监听代理，当网络异常时client会断线重连，断线时发送Event会失败
    [self.zySdk addZYClientOnlineDelegate:self];
    //设置SDK的登录状态监听（当用户登录状态切换时调用，例如登录状态过期、异地登录等）
    [self.zySdk setSDKLoginDelegate:self];
    
    self.myPhoneKeyhash=[self.zySdk getPhoneKeyhash];
    //init sdk end
    
    NSLog(@"sdk=%p, isLogin=%d, my phone keyhahs=%@,%@ ,hexS=%d",self.zySdk,isSDKLogin,self.myPhoneKeyhash,[self.zySdk getZotUrlBaseStr],[self.zySdk getIOTHexTypeSize]);
    
    
    //修改成你们的devTypeId 和测试keyhash
    self.devTypeId=@"1";//your dev devTypeId
    self.edtTargetKeyhash.text=@"you test devKeyhash";//you test dev
    
    //    self.edtTargetKeyhash.text=@"BZex9G8btXShJXpYrqcYgvX6Wu4=";//3
    
    self.childOnlineDicInfo=[[NSMutableDictionary alloc] init];
    NSString *text=_tvLogs.text;
    _tvLogs.text=[text stringByAppendingString:@"init正在启动ZYIOTSDK"];
    _valuesHexMap=[[NSMutableDictionary alloc] init];
    self.childDevKeyhash=@"8nWwEziWYZ4RP1oBStmTiXM6Unw=";//child dev-com
    self.edtTargetKeyhash.text=@"Bc1zh875nPEQkymQkzW3V6aj208=";//test 2号设备
    self.edtTargetKeyhash.text=@"7+j49oQr0WuEZHlNDQDVD5/NGE8=";
    self.edtEventAttrName.text=@"statew";
    //    self.edtEventAttrType.text=@"4";//string
    
    if([self.zySdk isSDKLogin]){
        //获取在登用户的设备列表
        [self.zySdk getDevListWithCompletion:^(NSMutableArray *devs, int retcode, NSString *errDescription) {
            [weakSelf updateLogsText:[NSString stringWithFormat:@"getDevList.retcode=%d,devs=%@,errText=%@",retcode,devs,errDescription]];
            
        }];
    }
    int64_t  now =[[NSDate date] timeIntervalSince1970];
    NSLog(@"now=%lld",now );
    
    
    self.edtEventAttrName.delegate=self;
    self.edtEventValue.delegate=self;
    self.edtEventAttrType.delegate=self;
    self.edtTargetKeyhash.delegate=self;
    self.edtTenantId.delegate=self;
    self.edtAccount.delegate=self;
    self.edtDevTypeId.delegate=self;
    //    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector (doneButtonshow:) name: UIKeyboardDidShowNotification object:nil];
     
    
    //    long long now=((long long)[[NSDate date] timeIntervalSince1970])*1000;
  
    [self.zySdk toASyncStartOrStopIOTClient:1];
    
}

-(void)testAPI{
    
    NSString *keyhash=_edtTargetKeyhash.text;
    __weak typeof(self) weakSelf=self;
    [self.zySdk getUserInfo:^(ZYUser *user, int retcode, NSString *errDescription) {
        NSString *info=!user?nil:[NSString stringWithFormat:@"user.lastPhoneType=%@,lastLoginWay=%@,lastLoginT=%@,language=%@,email=%@,phone=%@,phonePush=%@,personINfo=%@,pic=%@,phoneKeyhash=%@,pushSwitch=%d,emailSwitch=%d,wechatSwitch=%d,woauthId=%@,wpublicId=%@,smsRemain=%d,fontSize=%d",user.lastLoginPhoneType,user.lastLoginWay,user.lastLoginTime,user.language,user.email,user.phoneNum,user.phonePush,user.personalInfo,user.headProtrait,user.keyhash,user.pushSwitch,user.emailSwitch,user.wechatSwitch,user.wechatOauthOpenid,user.wechatPublicOpenid,user.smsRemain,user.fontSize];
        NSLog(@"%@",info);
        NSString *log=[NSString stringWithFormat:@"retcode=%d 获取用户信息%@，info=%@,e=%@",retcode,retcode==200?@"成功":@"失败",user,errDescription];
        [weakSelf updateLogsText:log];
    }];
    [self.zySdk getRegistVerifyWithAccount:@"12345678999" password:@"qwerty0" completion:^(ZYUserVerifyResult *result, int retcode, NSString *errDescription) {
        NSString *log=[NSString stringWithFormat:@"retcode=%d 获取注册验证码%@，e=%@",retcode,retcode==200?@"成功":@"失败",errDescription];
        [weakSelf updateLogsText:log];
    }];
    DeviceCameraInfo *camera=[[DeviceCameraInfo alloc] init];
    camera.accessToken=@"token";
    camera.cameraId=@"id";
    camera.password=@"pwd";
    camera.originalPassword=@"op";
    [self.zySdk devBindCameraWithkeyahsh:keyhash cameraInfo:camera completion:^(int retcode, NSString *errDescription) {
        NSString *log=[NSString stringWithFormat:@"retcode=%d 设置摄像头信息%@，e=%@",retcode,retcode==200?@"成功":@"失败",errDescription];
        [weakSelf updateLogsText:log];
        if(retcode==200){
            [weakSelf.zySdk getDevAttrListWithKeyhash:keyhash completion:^(DeviceInfoEntity *dev, int retcode, NSString *errDescription) {
                NSString *log=[NSString stringWithFormat:@"retcode=%d 获取设备属性%@，info=%@, e=%@",retcode,retcode==200?@"成功":@"失败",dev?[dev getDevCameraInfo]:@"no camera",errDescription];
                [weakSelf updateLogsText:log];
                [weakSelf.zySdk devDeleteCameraWithkeyahsh:keyhash completion:^(int retcode, NSString *errDescription) {
                    NSString *log=[NSString stringWithFormat:@"retcode=%d 删除摄像头信息%@，e=%@",retcode,retcode==200?@"成功":@"失败",errDescription];
                    [weakSelf updateLogsText:log];
                    
                    
                    
                }];
            }];
            
        }
    }];
    
    NSString *account=@"18850526607";
    NSString *chargeIdDev=@"5d149744b83ace1b85e6c354";//dev
  /*
    [self.zySdk getDevChargeInfos:^(NSMutableArray *chargeInfos, int retcode, NSString *errDescription) {
        NSString *log=[NSString stringWithFormat:@"retcode=%d 获取设备套餐%@，infos=%@,e=%@",retcode,retcode==200?@"成功":@"失败",chargeInfos,errDescription];
        [weakSelf updateLogsText:log];
        if(chargeInfos&&chargeInfos.count>3){
            ChargeInfoDev *charge=((ChargeInfoDev*)chargeInfos[3]);
            NSLog(@"购买Dev==》%@",charge);
            [weakSelf.zySdk getDevChargePayPriceWithChargeId:charge.chargeId  completion:^(ChargeInfoDev *chargeInfo, int retcode, NSString *errDescription) {
                NSString *log=[NSString stringWithFormat:@"retcode=%d 获取价格%@,info=%@，e=%@",retcode,retcode==200?@"成功":@"失败",chargeInfo,errDescription];
                [weakSelf updateLogsText:log];
            }];
           
            [weakSelf.zySdk deleteDevChargewithKeyhash:keyhash chargeMark:ZY_DevCharge_Type_LogRecorder completion:^(int retcode, NSString *errDescription) {
                NSString *log=[NSString stringWithFormat:@"retcode=%d 删除设备套餐%@, e=%@",retcode,retcode==200?@"成功":@"失败",errDescription];
                [weakSelf updateLogsText:log];
            }];
            
//            [weakSelf.zySdk buyDevChargeNoWithKeyhash:keyhash chargeId:charge.chargeId completion:^(int retcode, NSString *errDescription) {
//                 NSString *log=[NSString stringWithFormat:@"retcode=%d 购买设备套餐%@，e=%@",retcode,retcode==200?@"成功":@"失败",errDescription];
//                 [weakSelf updateLogsText:log];
//             }];
            [weakSelf.zySdk setDevPushEmailWithKeyhash:keyhash email:@"cxm@zy;yun@zyiot" completion:^(int retcode, NSString *errDescription) {
                NSString *log=[NSString stringWithFormat:@"retcode=%d 设置月推邮箱%@,e=%@",retcode,retcode==200?@"成功":@"失败",errDescription];
                [weakSelf updateLogsText:log];
            }];
            [weakSelf.zySdk getDevChargePurchasedInfosWithKeyhash:keyhash completion:^(NSMutableDictionary *purchasedInfoDic, int retcode, NSString *errDescription) {
                ChargeDevPurchase *info=(ChargeDevPurchase*)[purchasedInfoDic objectForKey:[NSString stringWithFormat:@"%d", ZY_DevCharge_Type_Operater]];
                ChargeDevPurchase *info2=(ChargeDevPurchase*)[purchasedInfoDic objectForKey:[NSString stringWithFormat:@"%d", ZY_DevCharge_Type_LogRecorder]];
                NSLog(@" token=%@ 购买的设备套餐描述detail=%@, %@",[weakSelf.zySdk getZotToken],info.details,info2);
                NSString *log=[NSString stringWithFormat:@"retcode=%d 获取设备购买的套餐%@，info=%@,e=%@",retcode,retcode==200?@"成功":@"失败",purchasedInfoDic,errDescription];
                [weakSelf updateLogsText:log];
            }];
            
        }
    }];
    [self.zySdk getSMSChargeInfos:^(NSMutableArray *smsChargeInfos, int retcode, NSString *errDescription) {
        NSString *log=[NSString stringWithFormat:@"retcode=%d 获取SMS套餐%@，infos=%@,e=%@",retcode,retcode==200?@"成功":@"失败",smsChargeInfos,errDescription];
        [weakSelf updateLogsText:log];
        if(smsChargeInfos&&smsChargeInfos.count>0){
            ChargeInfoSMS *charge=(ChargeInfoSMS *)smsChargeInfos[0];
            [weakSelf.zySdk getSMSChargePayPriceWithChargeId:charge.chargeId completion:^(ChargeInfoSMS *smsChargeInfo, int retcode, NSString *errDescription) {
                NSString *log=[NSString stringWithFormat:@"retcode=%d 获取SMS价格%@,info=%@，e=%@",retcode,retcode==200?@"成功":@"失败",smsChargeInfo,errDescription];
                [weakSelf updateLogsText:log];
            }];
//            NSLog(@"购买SMS==》%@",((ChargeInfoSMS *)smsChargeInfos[0]));
//            [weakSelf.zySdk buySMSChargeNoWithPhone:account chargeId:((ChargeInfoSMS *)smsChargeInfos[0]).chargeId completion:^(int retcode, NSString *errDescription) {
//                NSString *log=[NSString stringWithFormat:@" retcode=%d 购买短信套餐%@，e=%@",retcode,retcode==200?@"成功":@"失败",errDescription];
//                [weakSelf updateLogsText:log];
//            }];
        }
       
    }];
   */
    NSLog(@"token=%@",self.zySdk.getZotToken);
    [self.zySdk getUserListWithKeyhash:keyhash completion:^(NSMutableArray *authUsers, NSMutableArray *tempUsers, int retcode, NSString *errDescription) {
        NSString *log=[NSString stringWithFormat:@" retcode=%d 获取设备的用户列表%@,authUers=%@,tempUsers=%@，e=%@",retcode,retcode==200?@"成功":@"失败",authUsers,tempUsers,errDescription];
        [weakSelf updateLogsText:log];
        NSLog(@"%@",log);
    }];
    [self.zySdk setDevAttrsWithKeyhash:keyhash attrName:@"devname@zot" attrValue:@"卷帘门8" completion:^(int retcode, NSString *errDescription) {
        NSString *log=[NSString stringWithFormat:@" retcode=%d 修改设备名称%@，e=%@",retcode,retcode==200?@"成功":@"失败",errDescription];
        [weakSelf updateLogsText:log];
    }];
    [self.zySdk moveDevToUserWithPassword:@"qwerty0" keyhash:keyhash account:(NSString *)@"12345678999" completion:^(int retcode, NSString *errDescription) {
        NSString *log=[NSString stringWithFormat:@" retcode=%d 转移设备%@，e=%@",retcode,retcode==200?@"成功":@"失败",errDescription];
        [weakSelf updateLogsText:log];
    }];
    [self.zySdk setUserInfoWithNickname:@"小妹" msgSwitch:nil pushSwitch:nil wechatSwitch:nil phonePush:nil channelId:nil noDisturbTime:nil headProtrait:nil ring:nil language:@"zh" fontSize:0 personalInfo:nil completion:^(int retcode, NSString *errDescription) {
        NSString *log=[NSString stringWithFormat:@" retcode=%d setUserInfo%@，e=%@",retcode,retcode==200?@"成功":@"失败",errDescription];
        [weakSelf updateLogsText:log];
    }];
    [self.zySdk modifyPasswordWidthOldPassword:@"qwerty0" newPassword:@"qwerty1" completion:^(int retcode, NSString *errDescription) {
        NSString *log=[NSString stringWithFormat:@" retcode=%d 修改密码%@，e=%@",retcode,retcode==200?@"成功":@"失败",errDescription];
        [weakSelf updateLogsText:log];
//        [weakSelf.zySdk getModifyAccountVerifyWithAccount:@"chenxm@zhuyun-it.com" password:weakSelf.edtAcPwd.text completion:^(ZYUserVerifyResult *result, int retcode, NSString *errDescription) {
//            NSString *log=[NSString stringWithFormat:@" retcode=%d 获取修改账号的验证码%@，e=%@",retcode,retcode==200?@"成功":@"失败",errDescription];
//            [weakSelf updateLogsText:log];
//        }];
    }];
//    [weakSelf.zySdk modifyAccountWithAccount:@"chenxm@zhuyun-it.com" password:self.edtAcPwd.text verifyCode:@"4626" completion:^(int retcode, NSString *errDescription) {
//        NSString *log=[NSString stringWithFormat:@" retcode=%d 修改或绑定账号%@，e=%@",retcode,retcode==200?@"成功":@"失败",errDescription];
//        [weakSelf updateLogsText:log];
//    }];
    
}

-(void)appWillEnterForegroundNotification{
    NSLog(@"%d status=%d,切换前台now= %ld",[((AppDelegate*)[UIApplication sharedApplication].delegate) isNetworkReachable],(int)self.manger.networkReachabilityStatus,  (long)[[NSDate date] timeIntervalSince1970]);
   
    //    [self.zySdk toASyncStartOrStopIOTClient:1];
//    [self testAPI];
}

-(void)appDidEnterBackgroundNotification{
    NSLog(@"进入后台");
    //    [self.zySdk toASyncStartOrStopIOTClient:-1];
}




-(void)viewWillAppear:(BOOL)animated{
    NSLog(@"将要");
}

-(void)viewDidAppear:(BOOL)animated{
    //    [self.zySdk addZYClientOnlineDelegate:self];
    //    [self.zySdk addZYEventResponseDelegate:self];
    NSLog(@"页面显示");
}
-(void)viewDidDisappear:(BOOL)animated{
    //    [self.zySdk removeZYClientOnlineDelegate:self];
    //    [self.zySdk removeZYClientOnlineDelegate:self];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//点击return时隐藏输入键盘
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if ([string isEqualToString:@"\n"]) {
        [textField resignFirstResponder];
        return NO;
    }
    return YES;
}

-(void) hideKeyboard {
    [self.edtEventValue  resignFirstResponder];
    [self.edtEventAttrName  resignFirstResponder];
    [self.edtEventAttrType  resignFirstResponder];
    [self.edtTargetKeyhash  resignFirstResponder];
    [self.edtTenantId resignFirstResponder];
    [self.edtAccount resignFirstResponder];
    [self.edtDevTypeId resignFirstResponder];
    [self.edtAcPwd resignFirstResponder];
    [self.edtAccount resignFirstResponder];
}

-(IBAction)clearLogs:(UIButton *)btn{//清除UI上的运行结果显示
    self.tvLogs.text=@"";
}

-(void)updateLogsText:(NSString *)log{//UI显示运行结果
    [self hideKeyboard];
    NSString *text=@"";
    text=[text stringByAppendingString:[NSString stringWithFormat:@"%d. %@ \n %@",_logsLineNumber,log,_tvLogs.text]];
    _tvLogs.text=text;
    _logsLineNumber++;
}

-(void)loginToInitSDKWithTenantd:(int)tenantId phone:(NSString *)account password:(NSString *)pwd {
    __weak typeof(self) weakSelf=self;
    [self.zySdk setTenantId:tenantId];
    [self.zySdk loginWithAccount:account password:pwd phonePush:PhonePushType_development channelId:nil language:nil completion:^(ZYUserToken *token, int retcode, NSString *errDescription) {
        NSString *log=[NSString stringWithFormat:@"%d login结果=%@,e=%@,result=%@",retcode,token,errDescription,retcode==200?@"登录成功，SDK启动成功":@"SDK启动失败"];
        [weakSelf updateLogsText:log];
        //若登录失败，则后续SDK接口无法正常使用
    }];
   
}


//SDK 功能代码示例
- (IBAction)clickSendEvent:(id)sender {
    UIButton *btn=(UIButton *)sender;
    NSInteger tag= btn.tag;
    NSString *ret=nil;
    NSString *str=nil;
    _devTypeId=_edtDevTypeId.text ;
    NSString *targetKeyhash=self.edtTargetKeyhash.text;//targetKeyhash是指定设备的keyhash
    
    
    if(tag==-1){//login init sdk
        [self loginToInitSDKWithTenantd:[_edtTenantId.text intValue]  phone:_edtAccount.text password:_edtAcPwd.text];
        
        
//        [self.zySdk getForgetPwdVerifyWithAccount:@"18850526607" password:@"qwerty0" completion:^(ZYUserVerifyResult *result, int retcode, NSString *errDescription) {
//            NSString *log=[NSString stringWithFormat:@"retcode=%d 忘记密码z验证码%@, result=%@ ,e=%@",retcode,retcode==200?@"成功":@"失败",result,errDescription];
//            [self updateLogsText:log];
//        }];
//        [self.zySdk forgetPwdAndSetNewWithAccount:@"18850526607" password:@"qwerty1" verifyCode:@"6059" completion:^(int retcode, NSString *errDescription) {
//            NSString *log=[NSString stringWithFormat:@"retcode=%d 忘记密码%@，e=%@",retcode,retcode==200?@"成功":@"失败",errDescription];
//            [self updateLogsText:log];
//        }];
//        [self.zySdk deleteUserWithPassword:@"qwerty0" completion:^(int retcode, NSString *errDescription) {
//            NSString *log=[NSString stringWithFormat:@"retcode=%d 注销用户%@，e=%@",retcode,retcode==200?@"成功":@"失败",errDescription];
//            [self updateLogsText:log];
//        }];
        
//
//        [self.zySdk getRegistVerifyWithAccount:@"18850526607" password:@"qwerty0" completion:^(ZYUserVerifyResult *result, int retcode, NSString *errDescription) {
//            NSString *log=[NSString stringWithFormat:@"retcode=%d 获取注册用户验证码%@，info=%@,e=%@",retcode,retcode==200?@"成功":@"失败",result,errDescription];
//            [self updateLogsText:log];
//        }];
//        [self.zySdk registWithAccount:@"18850526607" password:@"qwerty3" verifyCode:@"1233" phonePush:nil channelId:nil language:nil completion:^(ZYUserToken *token, int retcode, NSString *errDescription) {
//            NSString *log=[NSString stringWithFormat:@"retcode=%d 注册用户%@，e=%@",retcode,retcode==200?@"成功":@"失败",errDescription];
//            [self updateLogsText:log];
        return;
    }
    
   
    
//
//        [self.zySdk getSceneListWithCompletion:^(NSMutableArray *devSceneInfos, int retcode, NSString *errDescription) {
//            [self updateLogsText:[NSString stringWithFormat:@" ret=%d,,err=%@,getScenList=%@",retcode,errDescription,devSceneInfos]];
//            NSLog(@"get Scenes=%@",devSceneInfos);
    //    [self.zySdk getDevLinkageListWithCompletion:^(NSMutableArray *devLinkages, int retcode, NSString *errDescription) {
    //        NSLog(@"\n%d,getLinkages=%@\n",retcode,devLinkages);
    //    }];
    //    [self.zySdk getDevTriggerListWithCompletion:^(NSMutableArray *devTriggers, int retcode, NSString *errDescription) {
    //        NSLog(@"%d,getTriggers=%@\n",retcode,devTriggers);
    //
    //    }];
    //    [self.zySdk getDevTimedTaskWithKeyhash:targetKeyhash completion:^(NSMutableArray *devTimedTasks, int retcode, NSString *errDescription) {
    //        NSLog(@"\n%d,getTimedTasks=%@",retcode,devTimedTasks);
    //
    //    }];
    //    [self.zySdk getDevAttrListForNoGlobalWithKeyhash:targetKeyhash completion:^(DeviceInfoEntity *dev, int retcode, NSString *errDescription) {
    //        NSLog(@"\n%d,getDevAttrNoglobal=%@",retcode,dev);
    //
    //    }];
    //    [self.zySdk getDevCustomTriggerListWithKeyhash:targetKeyhash completion:^(NSMutableArray *devCustomerTriggers, int retcode, NSString *errDescription) {
    //        NSLog(@"\n%d,getCustoemrTriggers=%@",retcode,devCustomerTriggers);
    //    }];
    //    NSString *jsonTest=@"{\"status\":true}";
    //    NSData *jsonData = [jsonTest dataUsingEncoding:NSUTF8StringEncoding];
    //    NSError *err;
    //    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
    //                                          options:NSJSONReadingMutableContainers
    //                                            error:&err];
    //    if(err)
    //    {
    //        NSLog(@"data parse exp[%@] data.length=%d",err.description,(int)jsonTest.length);
    //    }
    //    NSString *res=nil;//[NSString stringWithFormat:@"%@",[dic objectForKey:@"status"]];
    //    NSLog(@"token=%@,%d,%@,,%d,%@",[_zySdk getZotToken],[res boolValue],res.class, [res isKindOfClass:NSString.class],[NSString stringWithFormat:@"%@",[dic objectForKey:@"status"]]);
    ////    [self.zySdk addDevCustomTriggerWithKeyhash:targetKeyhash attrName:@"statew" condition:@"{\"operation\":\"contains\",\"threshold\":\"1\"}" timeLimit:@"{\"type\":\"0\"}" status:@"true" remark:@"ago" completion:^(NSString *triggerId, int retcode, NSString *errDescription) {
    ////        NSLog(@"%d addDevCumTrigger=%@,err=%@",retcode,triggerId,errDescription);
    ////    }];
    //    NSString *triggerId=@"5c12063024666436b09a8db9";
    //        [self.zySdk modifyDevCustomTriggerWithTriggerId:triggerId  keyhash:targetKeyhash attrName:@"state" condition:@"{\"operation\":\"contains\",\"threshold\":\"test\"}" timeLimit:@"{\"type\":\"1\",\"time\":\"1000-36000\"}" status:@"on" remark:@"gooo" completion:^(int retcode, NSString *errDescription) {
    //            NSLog(@"%d modifyDevCumTrigger=%@,err=%@",retcode,triggerId,errDescription);
    //        }];
    //
    //    triggerId=@"5c11f1a6246664137f8c337f";
    //    [self.zySdk deleteDevCustomTriggerWithTriggerId:triggerId completion:^(int retcode, NSString *errDescription) {
    //        NSLog(@"%d deleteCumTrigger=%@",retcode,errDescription);
    //    }];
    //    triggerId=@"5c11f83cbdcb1e1a7026080b";
    ////    [self.zySdk setDevTriggerSwitchWithKeyhash:targetKeyhash triggerId:triggerId triggerSwitch:@"TRUE" completion:^(int retcode, NSString *errDescription) {
    ////        NSLog(@"%d=set triggerSwitch=%@",retcode,errDescription);
    ////    }];
    //    NSArray *ids=[NSArray arrayWithObjects:triggerId,@"5c11f93824666436b09a8d8e", @"5c11f93824666436b09a8d8f",@"e", @"5c11f93824666436b09a8d90", @"5c11f93824666436b09a8d91",@"helkjh", @"5c11f93824666436b09a8d92", @"5c11f93824666436b09a8d93",@"5c11f93824666436b09a8d94",  nil];
    //    ids=[NSArray arrayWithObjects:targetKeyhash,@"test1", @"test2",@"e", @"test3", @"test4",@"helkjh", @"test2", @"test1",@"test4",  nil];
    //    for (int i=0; i<ids.count; i++) {
    ////        [self.zySdk getDevTriggerSwitchWithKeyhash:targetKeyhash triggerId:ids[i] completion:^(NSString *triggerId, NSString *triggerSwitch, int retcode, NSString *errDescription) {
    ////            NSLog(@"%d %d=get triggerSwitch.%@=%@",i,retcode,triggerId,triggerSwitch );
    ////        }];
    ////        [self.zySdk bindDevWithKeyhash:ids[i] devTypeId:_devTypeId completion:^(int retcode, NSString *errDescription) {
    ////            NSLog(@"%d %d=bindDev ",i,retcode );
    ////        }];
    ////        [self.zySdk getDevAttrListWithKeyhash:ids[i] completion:^(DeviceInfoEntity *dev, int retcode, NSString *errDescription) {
    ////            NSLog(@"%d %d=getDevInfo=%@",i,retcode,dev.keyhash );
    ////        }];
    //    }
    //    NSString *timeTaskId=@"5c130684d2446d5121177b16";
    //    [self.zySdk addDevTimedTaskWithKeyhash:targetKeyhash time:[NSString stringWithFormat:@"%lld" ,now0+100] attrName:@"statew" attrValue:@"hello timed " repeat:nil remark:@"timed222" sceneId:nil completion:^(NSString *timedTaskId, int retcode, NSString *errDescription) {
    //        NSLog(@"%d addTimedTask=%@",retcode,timedTaskId);
    //    }];
    //    [self.zySdk modifyDevTimedTaskWithTimedTaskId:timeTaskId keyhash:targetKeyhash time:@"32160" attrName:@"stater" attrValue:@"testTimedTask" repeat:@"145" remark:@"modify" sceneId:@"5c13081bd2446d5121177b18" completion:^(int retcode, NSString *errDescription) {
    //        NSLog(@"%d modifyTimedTask=%@",retcode,errDescription);
    //    }];
    ////    [self.zySdk deleteDevTimedTaskWithTimedTaskId:timeTaskId completion:^(int retcode, NSString *errDescription) {
    ////        NSLog(@"%d deleteTimedTask=%@",retcode,errDescription);
    ////    }];
    //    NSString *linkageId=@"5c122f78d2446d5121177af6";
    //    [self.zySdk addDevLinkageWithKeyhash:targetKeyhash attrName:@"statew" condition:@"{\"operation\":\"contains\",\"threshold\":\"hello\"}" keyhash2:targetKeyhash attrName2:@"stater" attrValue2:@"test link2" timeLimit:@"{\"type\":\"0\"}" remark:@"remakr" sceneId:nil completion:^(NSString *linkageId, int retcode, NSString *errDescription) {
    //        NSLog(@"%d addLinkage=%@",retcode,linkageId);
    //    }];
    ////    [self.zySdk modifyDevLinkageWithLinkageId:linkageId keyhash:targetKeyhash attrName:@"statew" condition:@"{\"operation\":\"contains\",\"threshold\":\"hell\"}" keyhash2:targetKeyhash attrName2:@"statew" attrValue2:@"test link3" timeLimit:@"{\"type\":\"1\",\"time\":\"0-1544746127\"}" remark:@"test link modify ." sceneId:nil completion:^(  int retcode, NSString *errDescription) {
    ////                NSLog(@"%d modifyLinkage",retcode);
    ////    }];
    //    [self.zySdk deleteDevLinkageWithLinkageId:linkageId completion:^(int retcode, NSString *errDescription) {
    //             NSLog(@"%d deleteLinkage",retcode);
    //    }];
    //
//    //
//        [self.zySdk addSceneWithSceneName:@"场景定时2" sceneType:ZY_Scene_Type_TimerTask remark:@"ki" completion:^(NSString *sceneId, int retcode, NSString *errDescription) {
//            NSLog(@"%d 增加定时的场景=%@,%@,e=%@",retcode,retcode==200?@"成功":@"失败",sceneId,errDescription);
    //    NSString *sceneId=@"5c13081bd2446d5121177b18";
    //    [self.zySdk modifySceneWithSceneId:sceneId sceneName:@"场景呀" remark:@"备注" completion:^(int retcode, NSString *errDescription) {
    //                NSLog(@"%d modify ",retcode);
    //    }];
    ////    [self.zySdk devResetDevWithKeyhash:targetKeyhash completion:^(int retcode, NSString *errDescription) {
    ////        NSLog(@"reset dev=%d",retcode);
    ////    }];
    //    [self.zySdk setDevPushSwitchWithKeyhash:targetKeyhash pushSwitch:@"false" emailSwitch:@"1" wechatSwitch:@"no" completion:^(int retcode, NSString *errDescription) {
    //        NSLog(@"set dev switch=%d",retcode);
    //    }];
    //    [self.zySdk getDevLogsWithKeyhash:targetKeyhash timestamp1:@"0" timestamp2:@"0" limit:@"3" completion:^(NSMutableArray *devLogs, int retcode, NSString *errDescription) {
    //        NSLog(@"%d getLogs=%@",retcode,(NSArray*)devLogs);
    //    }];
    //    [self.zySdk getDevAttrOperationWithDevTypeId:_devTypeId completion:^(NSMutableArray *attrOperations, int retcode, NSString *errDescription) {
    //        NSLog(@"%d get属性定义=%@",retcode,attrOperations);
    //    }];
    //    [self.zySdk modifySceneWithSceneId:sceneId sceneName:@"修场景"  remark:nil completion:^(int retcode, NSString *errDescription) {
    //        NSLog(@"modify scene=%d ",retcode );
    //    }];
    //    [self.zySdk getSceneInfoWithSceneId:sceneId completion:^(DeviceSceneInfo *scene, int retcode, NSString *errDescription) {
    //        NSLog( @"%d getSceneInfo=%@, =%@",retcode,scene,scene.tasks);
    //    }];
    //    Event是APP与设备进行通信的消息封装，包含设备属性名、属性值、属性值类型。
    NSString *attrName=self.edtEventAttrName.text;//发送Event与设备进行通信时指定的属性名
    int32_t attrType=[self.edtEventAttrType.text intValue];//指定属性值类型发送Event
    NSString *attrValue1=self.edtEventValue.text;//指定属性值类型为string时的属性值
    int32_t attrV2=[attrValue1 intValue];//指定属性值类型为int时的属性值
    int iotClientState= [self.zySdk getIOTClientState];//当前的IOT Client状态，当状态值为1或3时，可正常收发Event。
    NSString *logText=nil;
    [self updateLogsText:[NSString stringWithFormat:@"nowTimesecond=%lld ",(long long)[[NSDate date] timeIntervalSince1970]]];
    __weak typeof(self) weakSelf=self;
    if(tag==1) {//APP发送Event到设备，属性值类型是String
        //        attrName=@"statew";
        logText=[NSString stringWithFormat:@"iotState=%d本次Event即将发送name=%@,attrType=string,value=%@,dev=%@",iotClientState,attrName,attrValue1,targetKeyhash];
        [self updateLogsText:logText];
        //APP发送Event到设备，属性值类型是String
        ret=[self.zySdk sendEventStrFromApp:10 attrName:attrName valueStr:attrValue1 targetKeyhash:targetKeyhash];
        [self updateLogsText: [NSString stringWithFormat:@"1-ret.sendEvent.App.str=%@  ",ret]];
    }
    else if(tag==2) {//APP发送Event到设备，属性值类型是int
        //        attrName=@"inttest";
        logText=[NSString stringWithFormat:@"iotState=%d本次Event即将发送name=%@,attrType=int,value=%d,dev=%@",iotClientState,attrName,attrV2,targetKeyhash];
        [self updateLogsText:logText];
        ret=[self.zySdk sendEventIntFromApp:2 attrName:attrName valueInt:attrV2 targetKeyhash:targetKeyhash];
        [self updateLogsText: [NSString stringWithFormat:@"2-ret.sendEvent.App.int=%@",ret]];
    }
    
    else if(tag==3) {//APP发送Event到设备，属性值类型是hex(如语音文件的NSData内容)
        //        attrName=@"hextest";
        attrValue1=[NSString stringWithFormat:@"hexstr_%@",attrValue1];
        str=attrValue1;
        //这里是测试才用string，正常情况下发送hex语音文件数据内容而不是string转data数据
        NSData *data=[NSData dataWithData:[str dataUsingEncoding:NSUTF8StringEncoding]];
        //        Byte bs[6]={1,2,3,4,5,6};
        //        NSData *data=[NSData dataWithBytes:bs length:6];
        logText=[NSString stringWithFormat:@"iotState=%d本次Event即将发送name=%@,attrType=hex,value=%@,dev=%@",iotClientState,attrName,str,targetKeyhash];
        ret=[self.zySdk sendEventHexFromApp:3 attrName:@"hextest" valueHexBytes:data targetKeyhash:targetKeyhash];
        [self updateLogsText: [NSString stringWithFormat:@"3-ret.sendEvent.App.hex=%@,分片?hexLen=%d",ret,(int)data.length ]];
    }
    
    else if(tag==4) {//APP发送Event读取属性值，指定属性名读取对应的值（注意读取hex类型的属性的解析过程与string和int不一样）
        ret=[self.zySdk sendEventToReadDevAttrFromAPP:targetKeyhash attrName:attrName attrType:attrType];
        [self updateLogsText: [NSString stringWithFormat:@"(4)-ret.sendEvent.App.read[%@].type[%d]=%@",attrName,attrType,ret]];
    }
    
    
    else if(tag==7) {
        //绑定设备（扫描设备二维码得到keyhash ,devTypeId），设备只允许一个用户绑定，绑定后用户是设备的管理员，level=1是一级用户。可以分享设备给其他用户，其他用户为二级用户，level=2.
        [self.zySdk bindDevWithKeyhash:targetKeyhash devTypeId:self.devTypeId completion:^(int retcode, NSString *errDescription) {
            if(retcode==200){
                NSLog(@"绑定设备成功");
            }
            [weakSelf updateLogsText:[NSString stringWithFormat:@"bindDev[%@:%@].retcode=%d,errText=%@",weakSelf.devTypeId,targetKeyhash,retcode,errDescription]];
        }];
        
    }
    else if(tag==8) {//分享设备给用户
        
        long long now=((long long)[[NSDate date] timeIntervalSince1970]);
        NSString *authUserId=@"5b20de5c8bec6dcffc8315cb";//8账号的
        //设备管理员用户将设备授权分享给其他用户（此时被分享的用户就是指定设备的二级用户），指定设备targetKeyhash然后将设备分享给指定的用户（已注册筑云的手机或邮箱），authority为空时表示全时访问即每一天每时刻都可以控制设备（具体其他权限详见API ZYAccountSDK.h接口文档），remark是备注内容可以是昵称。
        [self.zySdk authorizeUserWithKeyhash:targetKeyhash account:@"12345678990" authority:[AuthorityEntity initAuthorityWithValidType:0] remark:@"妹妹" completion:^(ZYAuthUser *authUser,int retcode, NSString *errDescription) {
            if(retcode==200){
                NSLog(@"2 设备授权分享给用户成功 =%@",authUser);
            }
            [weakSelf updateLogsText:[NSString stringWithFormat:@"authUsertoDev2 .retcode=%d,errText=%@",retcode,errDescription]];
        }];
        AuthorityEntity2 *authority2=[[AuthorityEntity2 alloc] init];
        //创建权限封装:每周一周二的一点到十点允许用户控制设备
        authority2.time1=60;//1:00
        authority2.time2=36000;//10:00
        authority2.weekMode=@"12";//周一、周二
        authority2.shareTime=now;
        //设备管理员用户编辑二级用户权限（此时被分享的用户就是指定设备的二级用户），指定设备targetKeyhash，然后修改设备分享给指定的用户authUserId（用户ID）的权限，authority为空时表示全时访问即每一天每时刻都可以控制设备（具体其他权限详见API ZYAccountSDK.h接口文档），remark是备注内容可以是昵称。
        [self.zySdk modifyAuthUserWithKeyhash:targetKeyhash authUserId:authUserId authority:authority2 remark:@"修改权限" completion:^(int retcode, NSString *errDescription) {
            [weakSelf updateLogsText:[NSString stringWithFormat:@"修改二级用户权限%@ .retcode=%d,errText=%@",retcode==200?@"成功":@"失败",retcode,errDescription]];
        }];
         
         //管理员用户删除二级用户分享，按照指定设备targetKeyhash和二级用户authUserId（用户ID），可以删除设备的authUserId用户对targetKeyhash设备的控制权，即删除二级用户。
         [self.zySdk unAuthorizeUserWithKeyhash:targetKeyhash authUserId:authUserId completion:^(int retcode, NSString *errDescription) {
             if(retcode==200){
                 NSLog(@"删除二级用户成功");
             }
             [weakSelf updateLogsText:[NSString stringWithFormat:@"删除二级用户%@ .retcode=%d,errText=%@",retcode==200?@"成功":@"失败",retcode,errDescription]];
             [weakSelf.zySdk getUserListWithKeyhash:targetKeyhash completion:^(NSMutableArray *authUsers, NSMutableArray *tempUsers, int retcode, NSString *errDescription) {
                 NSString *log=[NSString stringWithFormat:@"%d获取设备的用户列表%@,users=%@,tempUsers=%@,e=%@",retcode,retcode==200?@"成功":@"失败",authUsers,tempUsers,errDescription];
             }];
         }];
        
        AuthorityTempEntity *authority=[[AuthorityTempEntity alloc] init];
        authority.timestamp1=now-6;//起点日期1
        authority.timestamp2=now+86400;//结束日期2
        authority.validType=0;//权限设置为时段访问
        authority.shareTime=now;
        //创建分享临时用户（临时用户无法在APP中使用，需要另外的网页——详情请z询问技术支持）
        [self.zySdk shareTempUserWithKeyhash:targetKeyhash authority:authority remark:@"临时工1号" completion:^(NSString *tempShareId, int retcode, NSString *errDescription) {
            [self updateLogsText:[NSString stringWithFormat:@"shareTemp%@=%@ retcode=%d,err=%@",retcode==200?@"成功":@"失败",tempShareId,retcode,errDescription]];
           
        }];
        NSString *tempShareId=@"tempUserId";
        authority.validType=1;//将临时用户的权限改为时段内单次
        [self.zySdk modifyTempUserWithTempShareId:tempShareId authority:authority remark:@"test-临时" completion:^(int retcode, NSString *errDescription) {
            [self updateLogsText:[NSString stringWithFormat:@"modifyTemp%@=%@ retcode=%d,err=%@",retcode==200?@"成功":@"失败",tempShareId,retcode,errDescription]];
        }];
    }
    
    else if(tag==9) {
        //用户删除设备，根据指定targetKeyhash设备，可以删除设备，删除后将无法控制设备。一级用户（管理员）删除设备将连带删除设备下的所有用户(包括二级用户和临时用户),二级用户删除设备则只是自己失去设备控制权限。
        [self.zySdk deleteDeviceWithKeyhash:targetKeyhash completion:^(int retcode, NSString *errDescription) {
            if(retcode==200){
                NSLog(@"用户删除设备成功");
            }
            [weakSelf updateLogsText:[NSString stringWithFormat:@"deleteDev .retcode=%d,errText=%@",retcode,errDescription]];
        }];
    }
    
    else if(tag==10) {
        //获取用户的设备列表，含一些特定属性，如在线状态、设备名称等
        [self.zySdk getDevListWithSomeAttrsWithCompletion:^(NSMutableArray *devs, int retcode, NSString *errDescription) {
            if(retcode==200){
                NSLog(@"获取设备列表成功， devs=%@",devs);
            }
            [weakSelf updateLogsText:[NSString stringWithFormat:@"getDevsWithAttrs .retcode=%d,devs=%@,errText=%@",retcode,devs,errDescription]];
        }];
        
        //获取用户的设备列表，不含任何属性值
        [self.zySdk getDevListWithCompletion:^(NSMutableArray *devs, int retcode, NSString *errDescription) {
            if(retcode==200){
                NSLog(@"获取设备列表成功， devs=%@",devs);
            }
            [weakSelf updateLogsText:[NSString stringWithFormat:@"getDevs .retcode=%d,devs=%@,errText=%@",retcode,devs,errDescription]];
        }];
    }
    else if(tag==11) {
        //获取指定设备的所有属性值，targetKeyhash是指定设备的keyhash
        [self.zySdk getDevAttrListWithKeyhash:targetKeyhash completion:^(DeviceInfoEntity *dev, int retcode, NSString *errDescription) {
            if(retcode==200){
                NSLog(@"获取设备属性all值成功 ，devInfo=%@",dev);
            }
            [weakSelf updateLogsText:[NSString stringWithFormat:@"getDevAttrs .retcode=%d,devs=%@,errText=%@",retcode,dev,errDescription]];
        }];
    }
    else if(tag==12) {
        //检测设备版本是否需要升级
        ZYFotaAPI *devFotaApi=[ZYFotaAPI getFotaInstance];//初始化接口实例
        if([devFotaApi connectStatus]!=1){//调用接口前定要先判断连接Fota的状态
            [devFotaApi openConnection];
        }
        NSLog(@"fota connectStatus=%d",[devFotaApi connectStatus]);
        //指定设备targetKeyhash进行检测是否升级，并指定结果回调接口
        [devFotaApi setDevUpdateWithDelegate:self keyhash:targetKeyhash];
        [devFotaApi checkDevUpdateVersion];//检测设备版本
        
    }
    
    
}

- (IBAction)clickToConnect:(id)sender {
    //需要与设备进行通信时，若getIOTClientState值不是1或3，可以选择以下接口手动启动IOT Client。
    [self.zySdk toASyncStartOrStopIOTClient:1];
}

- (IBAction)clickToDisConnect:(id)sender {
    //不需要与设备进行通信时可以暂时断开IOT Client
    [self.zySdk toASyncStartOrStopIOTClient:2];
}

- (IBAction)clickToDisConnectOver:(id)sender {
    //彻底不需要与设备进行通信时可以彻底断开IOT Client，如退出APP时
    [self.zySdk toASyncStartOrStopIOTClient:2];
}

#pragma mark->SDK Login manager delegate
-(void) sdkLoginSuccess{
    [self updateLogsText:@"SDK Login success"];
}

-(void) sdkLoginFailure:(int)retcode err:(NSString *)errDescription{
    [self updateLogsText:[NSString stringWithFormat:@"SDK失效，%d=%@",retcode,errDescription]];
}

#pragma mark ->ZYIOT manager delegate start.

#pragma mark MyEventResponseDelegate
/**
 接收到一个event消息，此时Event接收方是APP。ZY平台主动下发event时source无值。
 @param event 消息封装，包含设备属性名、属性值等
 @param source 发出Event的一方，指的是设备keyhash或null(平台)。如设备状态变更时发送Event通知APP，此时source是设备keyhash.
 */
-(void)onEventForAPP:(MyEventData *)event fromSource:(NSString *)source isRead:(BOOL)isRead readState:(BOOL)readState {
    int32_t eventId=event.eventId;//消息ID，可在发送Event时指定eventId
    int16_t attrType=event.attrType;//属性值的类型，根据不同的属性值类型解析不同的value字段，得到属性值。如type=1时，attrValue1为属性值。
    NSString *attrName=event.attrName;//属性名
    if([@"hextest" isEqual:attrName]){
        //读取hex类型的属性时，attrName=attrName，type=1，返回的是hex文件ID列表(形如objectId_timestamp,objectId_timestamp)。然后将文件ID列表中的objectId值作为attrName(此时type=4)依次发送event去获取文件内容。
        NSString *ids=event.attrValue1;
        if(ids){//hex类型的属性，允许有多个值，所以会有多个文件（string和int类型的属性，只有一个值）
            NSArray *fileIdStrs=[ids componentsSeparatedByString:@","];
            NSLog(@"fileIdStrs=%@",fileIdStrs);
            if(fileIdStrs&&fileIdStrs.count>0){
                int len=(int)fileIdStrs.count;
                for(int i=0;i<len;i++){
                    NSString *fileIdStr=fileIdStrs[i];
                    NSArray *infos=[fileIdStr componentsSeparatedByString:@"_"];
                    if(infos&&infos.count>0){
                        NSString *fileId=infos[0];//依次读取fileId对应的hex文件内容（文件太大时会分片后发送多个Event，记得组合后才是一个属性值）
                        [self.zySdk sendEventToReadDevAttrFromAPP:source attrName:fileId attrType:4];
                    }
                }
            }
        }
    }
    
    if(attrType==4){//属性值类型为4，表示此时Event封装的属性值是NSData类型，表示可能被分片传输，组合后才是完整的苏属性值
        //       当前分片从1开始计数。 若当前分片等于总片数则表示没有分片，则本属性值就是本Event的attrValue3。
        int16_t currentFrame=event.currentFrame;//当前分片，表示分片传输时，本Event的位置是第几片
        int16_t totalFrame=event.totalFrames;//总片数，表示分片传输时，一个hex文件属性值被分为几片
        //        将属性名和eventId作为组合分片数据内容时的标识键
        NSString *keyEvent =[NSString stringWithFormat:@"%@%d",attrName,eventId];
        NSMutableArray *datas=nil;
        if([self.valuesHexMap objectForKey:keyEvent]){//如果已经有接收到本属性名对应的分片
            datas=[self.valuesHexMap objectForKey:keyEvent];
            if(currentFrame==1 ){//一旦当前片数为1，则之前接收的相同属性标识键对应的分片数据需要清零，因为已经失效。（后台只允许一次发送一组分片数据——分片从1开始计数，不会许乱序发送）
                [self updateLogsText:[NSString stringWithFormat:@"%@[%d]=重新接收",attrName,eventId]];
                [datas removeAllObjects];
            }
            [datas addObject:event.attrValue3 ];//将本片数据暂时存储，以便在接收完所有分片后合并为属性值
        }else{
            datas=[[NSMutableArray alloc] init];
            [datas addObject:event.attrValue3 ];//将本片数据暂时存储，以便在接收完所有分片后合并为属性值
        }
        
        if(currentFrame==totalFrame){//当前分片与总片数相等，则表示所有分片接收完毕
            NSMutableData *data=[[NSMutableData alloc] init];
            for(int i=0;i<totalFrame;i++){ //在接收完所有分片后合并为属性值
                [data appendData:datas[i] ];
            }
            
            //data就是所有分片组合后得到的那个属性值（我测试时发送的是String内容，所以接下来打印出来）
            NSString *result=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            
            [self updateLogsText:[NSString stringWithFormat:@"%@[%d]={total=%d}接收到的分片Hex转为字符串为=%@",attrName,eventId,totalFrame,result]];
            if(data.length<6){
                [self updateLogsText:[NSString stringWithFormat:@"datas=[%@]",datas]];
            }
            [self.valuesHexMap removeObjectForKey:keyEvent];
        }else{
            [self.valuesHexMap setObject:datas forKey:keyEvent];
        }
    }
    [self updateLogsText:[NSString stringWithFormat:@"\t收到 [source=%@] Event回调=%@ ,frame[%d:%d]",source,event,event.totalFrames,event.currentFrame] ];
}

/**接收到一个event消息，此时接收方是app的直连子设备(不直接使用IOT的设备是子设备，对于APP来说子设备是APP直连子设备比如蓝牙设备，另外还有网关下挂的子设备)。监听到本event需要将值再发送给对应的子设备。
 @param event Event消息封装，包含设备属性名、属性值等
 @param source 发出这个Event的一方（表示对应的设备ID或null）
 @param childDevKeyhash 子设备ID（表示需要将这个Event的属性值再发给对应的子设备），如现用户的设备列表有一个蓝牙子设备C，此时接收到本Event[attrName=statew,type=1,attrValue1=2]且childDevKeyhash=C，那么APP通过蓝牙为C设备设置statew值为2。
 */
- (void)onEventForChildDev:(MyEventData *)event fromSource:(NSString *)source toChildDevKeyhash:(NSString *)childDevKeyhash isRead:(BOOL)isRead readState:(BOOL)readState{
    int32_t eventId=event.eventId;
    int16_t attrType=event.attrType;
    NSString *attrName=event.attrName;
    
    if([@"hextest" isEqual:attrName]){
        NSString *ids=event.attrValue1;
        if(ids){
            NSArray *fileIdStrs=[ids componentsSeparatedByString:@","];
            NSLog(@"fileIdStrs=%@",fileIdStrs);
            if(fileIdStrs&&fileIdStrs.count>0){
                int len=(int)fileIdStrs.count;
                for(int i=0;i<len;i++){
                    NSString *fileIdStr=fileIdStrs[i];
                    NSArray *infos=[fileIdStr componentsSeparatedByString:@"_"];
                    if(infos&&infos.count>0){
                        NSString *fileId=infos[0];
                        [self.zySdk sendEventToReadDevAttrFromAPP:source attrName:fileId attrType:4];
                    }
                }
            }
        }
    }
    
    if(attrType==4){
        int16_t currentFrame=event.currentFrame;
        int16_t totalFrame=event.totalFrames;
        NSString *keyEvent =[NSString stringWithFormat:@"%@%d",attrName,eventId];
        NSMutableArray *datas=nil;
        if([self.valuesHexMap objectForKey:keyEvent]){
            datas=[self.valuesHexMap objectForKey:keyEvent];
            if(currentFrame==1 ){
                [self updateLogsText:[NSString stringWithFormat:@"%@[%d]=重新接收",attrName,eventId]];
                [datas removeAllObjects];
            }
            [datas addObject:event.attrValue3];
        }else{
            datas=[[NSMutableArray alloc] init];
            [datas addObject:event.attrValue3];
        }
        
        if(currentFrame==totalFrame){
            NSMutableData *data=[[NSMutableData alloc] init];
            for(int i=0;i<totalFrame;i++){
                [data appendData:datas[i] ];
            }
            NSString *result=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            
            [self updateLogsText:[NSString stringWithFormat:@"%@[%d]={total=%d}接收到的分片Hex转为字符串为=%@ ",attrName,eventId,totalFrame,result]];
            if(data.length<6){
                [self updateLogsText:[NSString stringWithFormat:@"datas=[%@]",datas]];
            }
            [self.valuesHexMap removeObjectForKey:keyEvent];
        }else{
            [self.valuesHexMap setObject:datas forKey:keyEvent];
        }
    }
    [self updateLogsText:[NSString stringWithFormat:@"\t收到  chil Dev[source=%@] Event回调=%@ ,frame[%d:%d]",source,event,event.totalFrames,event.currentFrame] ];
}

/**
 event发送结果的回调
 @param isSuccess true表示成功发送到IOT服务器，false表示失败
 @param eventId 发送Event时指定的或返回的消息ID
 */
-(void)onEventSyncResponseWithStatus:(BOOL)isSuccess eventId:(int32_t)eventId{
    [self updateLogsText:[NSString stringWithFormat:@"\t已发送eventId=[%d]=%d ",eventId,isSuccess]];
}

/**子设备登录和退出登录时的结果回调
 @param loginResult 登录或退出登录的结果
 @param isLogin 表示登录或退出登录，true表示登录，false表示退出登录。
 @param childDevKeyhash 是这个子设备的登录（退出登录）
 @param childDevType 本子设备的类型（如蓝牙或串口，分别是bluetooth和com，都是小写字母）
 */
-(void)onEventForChildDevLoginOrOut:(BOOL)loginResult isLogin:(BOOL)isLogin childDevKeyhash:(NSString *)childDevKeyhash childDevType:(NSString *)childDevType{
    if(isLogin){
        [self.childOnlineDicInfo setObject:@"1" forKey:childDevKeyhash];
    }else{
        [self.childOnlineDicInfo removeObjectForKey:childDevKeyhash];
    }
    [self updateLogsText:[NSString stringWithFormat:@"\t收到 child login or out回调 dev=%@,loginResult=%d,isLogin=%d,devType=%@  ",childDevKeyhash,loginResult,isLogin,childDevType ]];
}
//发送event后，接收event失败。eventId是消息ID，发送event时可以指定
-(void)onEventFailureWithEventId:(int32_t)eventId{
    [self updateLogsText:[NSString stringWithFormat:@"\tevent failure=%d",eventId]];
}

#pragma mark IOTOnlineDelegate
- (void)onIOTConnect{//IOT 连接成功时回调
    NSLog(@"IOT Connect");
    [self updateLogsText:[NSString stringWithFormat:@" ZYIOT Connect now=%ld" ,(long)[[NSDate date] timeIntervalSince1970]]];
}

- (void)onIOTDisConnect{//IOT 异常断开时回调
    NSLog(@"IOT DisConnect");
    [self updateLogsText:[NSString stringWithFormat:@" ZYIOT DisConnect now=%ld" ,(long)[[NSDate date] timeIntervalSince1970]]];
}

#pragma mark ZYIOTClientStateDelegate
-(void)onStopped{//IOT被手动stop时回调
    NSLog(@"IOT stop.");
}
-(void)onStarted{//IOT被手动start时回调，表示正在start
    NSLog(@"IOT start.");
}
-(void)onResume{//IOT被手动resume时回调
    NSLog(@"IOT resume.");
}
-(void)onPaused{//IOT被手动pause时回调
    NSLog(@"IOT pause.");
}

#pragma mark -->ZYIOT manager delegate end.

#pragma Fota delegate (retcode==1 is ok)
/**获取设备固件升级进度
 @param retcode retcode=1时成功，其余数字表示失败
 @param keyhash keyhash fota模块当前keyhash
 @param isNewest isNewest true表示本设备已经是最新的设备
 @param isForceUpdate 本设备固件的当前版本若不是最新版本，固件不升级是否可用。true表示固件不升级就无法正常使用。
 @param currentV 本设备的当前版本
 @param newestV 本设备对应的最新的设备固件
 */
- (void)callCheckDevUpdateWithRetcode:(int16_t)retcode keyhash:(NSString *)keyhash isNewest:(BOOL)isNewest isForceUpdate:(BOOL)isForceUpdate currentVer:(NSString *)currentV newestVer:(NSString *)newestV {
    NSLog(@"升级时回调 retcode=%d, isNewest=%d isForce=%d, keyhash=%@",retcode,isNewest,isForceUpdate,keyhash);
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self updateLogsText:[NSString stringWithFormat:@"fota.getVersion.code=%d,isNewest=%d,keyhash=%@",retcode,isNewest,keyhash]];
    });
    
    if(retcode==1){//成功获取版本信息
        if(isNewest==NO)
        {
            NSString *result=[[ZYFotaAPI getFotaInstance] setDevUpdateStart];//通知设备升级（是通过Event通知设备升级的，由SDK内部发送消息）
            NSLog(@"result=%@",result);
            if([result intValue]!=0){//发出升级命令
                [[ZYFotaAPI getFotaInstance] getDevUpdateProgress];//获取设备升级进度（通知设备升级成功后，才有进度值）
            }
        }
    }
}

/**获取设备固件升级进度
 @param retcode retcode=1时成功，其余数字表示失败
 @param keyhash keyhash fota模块当前keyhash
 @param progress 设备固件升级的进度
 */
- (void)callGetDevUpdateProgressWithRetcode:(int16_t)retcode keyhash:(NSString *)keyhash progress:(int)progress {
    NSLog(@"percentage升级时回调进度 retcode=%d, keyhash=%@ per=%d",retcode,keyhash,progress);
    if(retcode==1){//成功获取版本升级进度
        //continue get progress ? 如果需要持续接收进度，可以继续调用获取进度的接口
        if(progress!=100){
            NSLog(@"继续获取进度");
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [[ZYFotaAPI getFotaInstance] getDevUpdateProgress];
            });
        }
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        [self updateLogsText:[NSString stringWithFormat:@"fota.getProgress.code=%d,progress=%d,keyhash=%@",retcode,progress,keyhash]];
    });
    
    
}

//连接Fota模块断开
- (void)onCloseConnectToFota {
    NSLog(@"检测升级结束-----");
}

#pragma Fota delegate end




@end

