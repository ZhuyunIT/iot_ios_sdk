//
//  ViewController.m
//  ZYIOTSdkDemo_2_2
//
//  Created by zy-cxm on 2018/10/22.
//  Copyright © 2018年 zy-cxm. All rights reserved.
//

#import "ViewController.h"
#import "ZYOpenAccountSDK.h"
#import "AboutZYEntity.h"
#import "ZYFotaApi.h"
#import "ZYAccountSDK.h"
#import "AFNetworkReachabilityManager.h"

#import "AppDelegate.h"

#import <SystemConfiguration/SCNetworkReachability.h>
#import <netdb.h>

#import <dlfcn.h>

@interface ViewController ()<MyEventResponseDelegate, ZYDevUpdateDelegate,IOTOnlineDelegate,ZYIOTClientStateDelegate,ZYSDKLoginDelegate,UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextView *tvLogs;//显示打印记录

@property (weak, nonatomic) IBOutlet UITextField *edtTenantId;//tenantId
@property (weak, nonatomic) IBOutlet UITextField *edtAppToken;//user appToken
@property (weak, nonatomic) IBOutlet UITextField *edtDevTypeId;//设备类型ID

@property (strong, nonatomic) NSString *childDevKeyhash;//test子设备接口时用的keyhash
@property (weak, nonatomic) IBOutlet UITextField *edtTargetKeyhash;// 以下API用的dev keyhash
@property (weak, nonatomic) IBOutlet UITextField *edtEventAttrName;//设备属性名
@property (weak, nonatomic) IBOutlet UITextField *edtEventAttrType;//设备属性值类型
@property (weak, nonatomic) IBOutlet UITextField *edtEventValue;//设备属性值
@property (strong, nonatomic) NSString *zotToken;//SDK初始化后得到的zotToken
@property (strong,nonatomic) UIButton *doneButton;
@property int logsLineNumber;
@property (nonatomic,strong) NSMutableDictionary *valuesHexMap;//为了接收hex分片Event。<attrName+eventId,array<NSData>>
@property (strong,nonatomic) ZYOpenAccountSDK *zyOpenSdk;
@property (strong,nonatomic) NSMutableDictionary *childOnlineDicInfo;//记录子设备是否登录在线，子设备在线发送event才会成功

@property (strong,nonatomic) NSString *devTypeId;//不同的设备可能会是不同的设备类型，一般一个厂家一个设备类型。
@property (strong, nonatomic) NSString *myPhoneKeyhash;//本机Keyhash

//@property ( nonatomic)int your_tenantId;//=2;//筑云提供的特定的值tenantId
@property (strong, nonatomic)NSString *your_appId;//=@"5bf6180ba83c52d8da80725f";//筑云提供的特定的值appID
@property (strong, nonatomic)NSString *your_appSecret;//=@"qpItb2z7cXn9vhaWpRo5iewXZta6dH";//筑云提供的特定的值appSecret


@property (strong) NSOperationQueue *queue;
@property (strong) NSTimer *timer;
@property (strong) NSTimer *timer2;
@property (strong,nonatomic)  AFNetworkReachabilityManager *manger ;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appWillEnterForegroundNotification) name:UIApplicationWillEnterForegroundNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appDidEnterBackgroundNotification) name:UIApplicationDidEnterBackgroundNotification object:nil];
    __weak typeof(self) weakSelf=self;
    /**
     1、属性：根据设备类型由厂家规定，包含属性名、属性值类型。（属性规定，详见厂家设备属性定义文档）。
     2、Event是APP与设备进行通信的消息封装，包含设备属性名、属性值、属性值类型。
     3、ZYIOTSDK主要分为三块：FOTA、IOT、IOT。分别指代：FOTA设备固件升级模块；IOT设备通信的专用通道；ZOT用户与设备等的业务处理（除了FOTA与IOT之外的业务）；
     4、本Demo只是使用SDK的示例，展示主要功能：启动SDK、绑定设备、删除设备、控制设备、获取设备列表、获取设备所有属性、、分享设备(增加、编辑、删除分享)、设备固件升级功能。其他功能接口的介绍，详见API文档（ZYOpenAccountSDK.h和ZYBaseSDK.h）
     5、SDK一定要先初始化启动成功才能正常使用。
     6、本Demo运行正常前提：
     **启动SDK时填入筑云提供给第三方的appId、appSecret，以及第三方用户appToken（回调时返回码是200，SDK启动成功）；
     绑定设备时devTypeId和keyhash要正确（调用接口时记的将devTypeId改为自己厂家设备对应的devTypeId）。
     */
    
    //init sdk start
    self.edtAppToken.text=@"585f62417b0e4078beb629af980ac230";
    //初始化：SDK一定要先初始化启动成功才能正常使用。
    //(以下四个参数请分别填写您的tenantId, appId, appSecret, 以及第三方平台用户appToken)。
    int your_tenantId=[self.edtTenantId.text intValue];//筑云提供的特定的值tenantId
    self.your_appId=@"5bf6180ba83c52d8da80725f";//筑云提供的特定的值appID
    self.your_appSecret=@"qpItb2z7cXn9vhaWpRo5iewXZta6dH";//筑云提供的特定的值appSecret
    NSString *your_user_appToken=_edtAppToken.text;//appToken是第三方用户登录第三方平台得到的用户token
    [self initSDKWithTenantd:[_edtTenantId.text intValue] appToken:_edtAppToken.text];
//    [self initSDKWithTenantd:[_edtTenantId.text intValue] appToken:_edtAppToken.text];
//    [self initSDKWithTenantd:[_edtTenantId.text intValue] appToken:_edtAppToken.text];
//    [self initSDKWithTenantd:[_edtTenantId.text intValue] appToken:_edtAppToken.text];
//    [self initSDKWithTenantd:[_edtTenantId.text intValue] appToken:_edtAppToken.text];
//    [self initSDKWithTenantd:[_edtTenantId.text intValue] appToken:_edtAppToken.text];
//    [self initSDKWithTenantd:[_edtTenantId.text intValue] appToken:_edtAppToken.text];
    self.zyOpenSdk=[ZYOpenAccountSDK getZYOpenAccountSDKInstance];
//    [self.zyOpenSdk toASyncStartOrStopIOTClient:1];
//        [ZYOpenAccountSDK initZYOpenAccountSDKWithTenantId:your_tenantId appId:your_appId appSecret:your_appSecret appToken:your_user_appToken completion:nil];
    //    [self.zyOpenSdk setZotToken:@"4HULmpQSDDq6JZY"];
//        [self.zyOpenSdk setZotDomain:@"192.168.10.114"];
//        [self.zyOpenSdk setZotPort:8080];
//        [self.zyOpenSdk setIOTServer:@"zhuyun-it.imwork.net;zhuyun.f3322.net;"];
    BOOL isSDKLogin=[self.zyOpenSdk isSDKLogin] ;//SDK 登录状态获取
//        [[ZYFotaAPI getFotaInstance] setFotaDomain:@"192.168.10.12"];
//    [[ZYFotaAPI getFotaInstance] setFotaPort:9324];
    
    //    默认的服务器有效，不需要修改也可以。IOT、ZOT、FOTA服务器域名指向有效，默认的服务器指向是有效的，可以不用改，（如果重新部署迁移服务器，需要重新set）
            [self.zyOpenSdk setZotDomain:@"zhuyun.f3322.net"];//ZOT模块服务器IP入口
    //    [self.zyOpenSdk setZotPort: 9390];
            [self.zyOpenSdk setIOTServer:@"zhuyun.f3322.net"];//IOT模块服务器多IP入口，多个时用英文分号隔开
//        [[ZYFotaAPI getFotaInstance] setFotaDomain:@"iot.zhuyun-it.com"];//FOTA服务器是单IP入口
    
    //设置IOT Client状态变化监听代理：可以得到IOT Client的状态。当状态值为1或3时可以正常发送Event与设备通信。
    [self.zyOpenSdk setIOTClientStateDelegate:self];
    
    //设置event发送与接收的结果监听代理。与设备进行通信时的消息封装是Event。实现这个代理可以实时监听设备状态变化。如APP可以收到在Event[online@zot=0](表示设备掉线)时刷新UI.
    [self.zyOpenSdk addZYEventResponseDelegate:self];
    
    //设置IOT Client在线与异常离线的监听代理，当网络异常时client会断线重连，断线时发送Event会失败
    [self.zyOpenSdk addZYClientOnlineDelegate:self];
    
    [self.zyOpenSdk setSDKLoginDelegate:self];
    
    self.myPhoneKeyhash=[self.zyOpenSdk getPhoneKeyhash];
    //init sdk end
    
    NSLog(@"sdk=%p, isLogin=%d, my phone keyhahs=%@,%@ ,hexS=%d",self.zyOpenSdk,isSDKLogin,self.myPhoneKeyhash,[self.zyOpenSdk getZotUrlBaseStr],[self.zyOpenSdk getIOTHexTypeSize]);
    
    
    //修改成你们的devTypeId 和测试keyhash
    self.devTypeId=@"23";//your dev devTypeId
    self.edtTargetKeyhash.text=@"you test devKeyhash";//you test dev
    
//    self.edtTargetKeyhash.text=@"BZex9G8btXShJXpYrqcYgvX6Wu4=";//3
    
    self.childOnlineDicInfo=[[NSMutableDictionary alloc] init];
    NSString *text=_tvLogs.text;
    _tvLogs.text=[text stringByAppendingString:@"init正在启动ZYIOTSDK"];
    _valuesHexMap=[[NSMutableDictionary alloc] init];
    self.childDevKeyhash=@"8nWwEziWYZ4RP1oBStmTiXM6Unw=";//child dev-com
        self.edtTargetKeyhash.text=@"Bc1zh875nPEQkymQkzW3V6aj208=";//test 2号设备
    self.edtEventAttrName.text=@"statew";
    //    self.edtEventAttrType.text=@"4";//string
    
    if([self.zyOpenSdk isSDKLogin]){
        //获取appToken对应账号下的设备列表(初始化SDK时传入的appToken对应的用户)
        [self.zyOpenSdk getDevListWithCompletion:^(NSMutableArray *devs, int retcode, NSString *errDescription) {
            [weakSelf updateLogsText:[NSString stringWithFormat:@"getDevList.retcode=%d,devs=%@,errText=%@",retcode,devs,errDescription]];
            
        }];
    }
    int64_t  now =[[NSDate date] timeIntervalSince1970];
    NSLog(@"now=%lld",now );
    
    
    self.edtEventAttrName.delegate=self;
    self.edtEventValue.delegate=self;
    self.edtEventAttrType.delegate=self;
    self.edtTargetKeyhash.delegate=self;
    self.edtTenantId.delegate=self;
    self.edtAppToken.delegate=self;
    self.edtDevTypeId.delegate=self;
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector (doneButtonshow:) name: UIKeyboardDidShowNotification object:nil];
    
   
//    [self.zyOpenSdk setIOTServer:@"106.122.190.121"];
    
//    long long now=((long long)[[NSDate date] timeIntervalSince1970])*1000;
    NSString *time=[NSString stringWithFormat:@"%lld-%lld",now-60,now+660];
    NSDictionary *dict=[[NSDictionary alloc] initWithObjectsAndKeys:@"1",@"type",time,@"time" , nil];
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&error];
    NSString *jsonString;
    if (!jsonData) {
        NSLog(@"%@",error);
    }else{
        jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
    };
    BOOL result=[self checkUserValidWithKeyhash:jsonString];
    NSLog(@"有权限 %d",result);
    
    time=[NSString stringWithFormat:@"%lld-%lld",now-60,now-1];
    dict=[[NSDictionary alloc] initWithObjectsAndKeys:@"1",@"type",time,@"time" , nil];
    jsonData = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&error];
    if (!jsonData) {
        NSLog(@"%@",error);
    }else{
        jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
    };
    result=[self checkUserValidWithKeyhash:jsonString];
    NSLog(@"无权限 %d",result);
 
//    [self.zyOpenSdk toASyncStartOrStopIOTClient:2];
//    [self.zyOpenSdk toASyncStartOrStopIOTClient:-1];
//    [self.zyOpenSdk toASyncStartOrStopIOTClient:1];
//    [self.zyOpenSdk toASyncStartOrStopIOTClient:2];
//    [self.zyOpenSdk toASyncStartOrStopIOTClient:-1];
//    [self.zyOpenSdk toASyncStartOrStopIOTClient:1];
//    [self.zyOpenSdk toASyncStartOrStopIOTClient:2];
    [self.zyOpenSdk toASyncStartOrStopIOTClient:1];
    //1.创建网络状态监测管理者
    AFNetworkReachabilityManager *manger = [AFNetworkReachabilityManager sharedManager];
    
    //2.监听改变
    [manger setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        
        NSLog(@"切换net now= %ld， status=%d",  (long)[[NSDate date] timeIntervalSince1970], (int)status);
        /*
         AFNetworkReachabilityStatusUnknown          = -1,
         AFNetworkReachabilityStatusNotReachable     = 0,
         AFNetworkReachabilityStatusReachableViaWWAN = 1,
         AFNetworkReachabilityStatusReachableViaWiFi = 2,
         */
        switch (status) {
            case AFNetworkReachabilityStatusUnknown:
                NSLog(@"未知");
                break;
            case AFNetworkReachabilityStatusNotReachable:
                NSLog(@"没有网络");
                break;
            case AFNetworkReachabilityStatusReachableViaWWAN:
                NSLog(@"3G|4G");
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi:
                NSLog(@"WiFi");
                break;
            default:
                break;
        }
    }];
    
    [manger startMonitoring];
    self.manger=manger;
    [self testHttpValid];
    [AppDelegate scheduleReachabilityWatcher:self];
}

-(void)testHttpValid{
//    [self.zyOpenSdk setZotDomain:@"iot.zhuyun-it.com"];
//    [self.zyOpenSdk setTenantId:2];
//    [self.zyOpenSdk setZotDomain:@"zhuyun.f3322.net"];
//    [self.zyOpenSdk setZotToken:@"kkkk"];
//    [self.zyOpenSdk setZotRefreshToken:@"etst"];
    long now=[[NSDate date] timeIntervalSince1970];
//    [self.zyOpenSdk getDevAttrListWithKeyhash:self.edtTargetKeyhash.text  completion:^(DeviceInfoEntity *dev, int retcode, NSString *errDescription) {
//        NSLog(@"%d tatus=%d 获取设备=%d,耗时=%ld",[self isNetworkReachable],(int)self.manger.networkReachabilityStatus,retcode,  (long)[[NSDate date] timeIntervalSince1970]-now);
//        [self updateLogsText: [NSString stringWithFormat:@"%d tatus=%d 获取设备=%d,耗时=%ld, now=%ld",[self isNetworkReachable],(int)self.manger.networkReachabilityStatus,retcode,  (long)[[NSDate date] timeIntervalSince1970]-now,(long)[[NSDate date] timeIntervalSince1970]]];
//    }];
//    [[ZYAccountSDK getZYAccountSDKInstance] loginWithAccount:@"12345678999" pwd:@"12345678999" phonePush:@"ios_0" channelId:nil appKeyhash:nil language:nil completion:^(ZYUserToken *uToken, int retcode, NSString *errDescription) {
//         [self updateLogsText: [NSString stringWithFormat:@"%d tatus=%d 获取Login=%d,耗时=%ld, now=%ld",[self isNetworkReachable],(int)self.manger.networkReachabilityStatus,retcode,  (long)[[NSDate date] timeIntervalSince1970]-now,(long)[[NSDate date] timeIntervalSince1970]]];
//    }];
    
}

-(void)appWillEnterForegroundNotification{
    NSLog(@"%d status=%d,切换前台now= %ld",[((AppDelegate*)[UIApplication sharedApplication].delegate) isNetworkReachable],(int)self.manger.networkReachabilityStatus,  (long)[[NSDate date] timeIntervalSince1970]);
    [self testHttpValid];
//    [self.zyOpenSdk toASyncStartOrStopIOTClient:1];
}

-(void)appDidEnterBackgroundNotification{
    NSLog(@"进入后台");
//    [self.zyOpenSdk toASyncStartOrStopIOTClient:-1];
}


-(BOOL)checkUserValidWithKeyhash:(NSString *)authority{
    if(!authority){
        return NO;
    }
    if([@"1" isEqual:authority]){//admin level=1
        return YES;
    }
    //    权限说明，json格式数据，包含字段说明：type：操控类型，0表示全时访问，无需time和week；1表示时段访问，无需week；2表示定期访问。time表示操控时间，如果是时段访问，内容为起始-结束时间戳，中间用-分割；如果是定期访问，内容为当天时间的起始秒-结束秒，中间用-分割。week表示星期，1-7分别表示周一到周日，如：137表示周一周三周日。shareTime表示分享时间，为时间戳。
    NSDictionary *dicInfo=[self toDictionaryWithJsonString:authority];
    if(!dicInfo){
        return NO;
    }
    int type=[[dicInfo objectForKey:@"type"] intValue];
    if(type==0){
        return YES;
    }
    NSString *timeStr=[dicInfo objectForKey:@"time"];
    if(timeStr&&[timeStr componentsSeparatedByString:@"-"].count<2){
        return NO;
    }
    NSArray *times=[timeStr componentsSeparatedByString:@"-"];
    long long time1=[times[0] longLongValue];
    long long time2=[times[1] longLongValue];
    if(type==1){
        long long now=(long long)[[NSDate date] timeIntervalSince1970]*1000;
        NSLog(@"len=%d",(int)((NSString *)times[0]).length);
        if(((NSString *)times[0]).length<11){
            time1=time1*1000;
            time2=time2*1000;
        }
        if(time1<=now&&now<=time2){
            return YES;
        }
    }else if(type==2){
        NSString *week=[dicInfo objectForKey:@"week"];
        if(!week){
            return NO;
        }
        NSDate *date=[NSDate  date];
        NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
        NSDateComponents *comps = [[NSDateComponents alloc] init];
        NSInteger unitFlags =  NSCalendarUnitWeekday ;
        comps = [calendar components:unitFlags fromDate:date];
        int weekNow = (int)[comps weekday]-1;//(获取的week1是周日)
        if(weekNow==0){
            weekNow=7;
        }
        if([week containsString:[NSString stringWithFormat:@"%d",weekNow]]){
            NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
            [formatter setDateFormat:@"HH"];
            int hourNow=[[formatter stringFromDate:date] intValue];
            [formatter setDateFormat:@"mm"];
            int minuteNow=[[formatter stringFromDate:date] intValue];
//            int hour1=(int)time1/(60*60);
                        int minute2=(int)(time2%(60*60))/60;
//            int hour2=(int)time2/(60*60);
            //            int minute2=(int)time2%(60*60);
            long secondNow=hourNow*60*60+minuteNow*60;
            NSLog(@"%ld %d:%d  %lld  %d",secondNow,hourNow,minuteNow,time2,minute2);
            if(time1<time2){
                if(time1<=secondNow&&secondNow<=time2){
                    return YES;
                }
            }else{
                if((time1<=secondNow&&secondNow<=86400)||(0<=secondNow&&secondNow<=time2)){
                    return YES;
                }
            }
        }
        
    }
    return NO;
}

//2. JSON字符串转化为字典
- (NSDictionary *)toDictionaryWithJsonString:(NSString *)jsonString
{
    if (jsonString == nil||jsonString.length==0) {
        return nil;
    }
    NSDictionary *dic=nil;
    @try{
        NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
        NSError *err;
        dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                              options:NSJSONReadingMutableContainers
                                                error:&err];
        if(err)
        {
            NSLog(@"data parse exp[%@] data.length=%d",err.description,(int)jsonString.length);
            return nil;
        }
    }@catch(NSException *e1){
        NSLog(@"json exp=%@",e1);
    }
    @catch(NSError *err){
        NSLog(@"json err=%@",err);
    }
    
    return dic;
}

-(void)viewWillAppear:(BOOL)animated{
    NSLog(@"将要");
}

-(void)viewDidAppear:(BOOL)animated{
//    [self.zyOpenSdk addZYClientOnlineDelegate:self];
//    [self.zyOpenSdk addZYEventResponseDelegate:self];
    NSLog(@"页面显示");
}
-(void)viewDidDisappear:(BOOL)animated{
//    [self.zyOpenSdk removeZYClientOnlineDelegate:self];
//    [self.zyOpenSdk removeZYClientOnlineDelegate:self];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//点击return时隐藏输入键盘
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if ([string isEqualToString:@"\n"]) {
        [textField resignFirstResponder];
        return NO;
    }
    return YES;
}

-(void) hideKeyboard {
       [self.edtEventValue  resignFirstResponder];
       [self.edtEventAttrName  resignFirstResponder];
       [self.edtEventAttrType  resignFirstResponder];
       [self.edtTargetKeyhash  resignFirstResponder];
    [self.edtTenantId resignFirstResponder];
    [self.edtAppToken resignFirstResponder];
    [self.edtDevTypeId resignFirstResponder];
}

-(IBAction)clearLogs:(UIButton *)btn{//清除UI上的运行结果显示
    self.tvLogs.text=@"";
}

-(void)updateLogsText:(NSString *)log{//UI显示运行结果
    [self hideKeyboard];
    NSString *text=@"";
    text=[text stringByAppendingString:[NSString stringWithFormat:@"%d. %@ \n %@",_logsLineNumber,log,_tvLogs.text]];
    _tvLogs.text=text;
    _logsLineNumber++;
}

-(void)initSDKWithTenantd:(int)tenantId appToken:(NSString *)appToken {
    __weak typeof(self) weakSelf=self;
    self.zyOpenSdk= [ZYOpenAccountSDK initZYOpenAccountSDKWithTenantId:tenantId appId:_your_appId appSecret:_your_appSecret appToken:appToken completion:^(ZYUserToken *uToken, int retcode, NSString *errDescription) {
        NSString *result=nil;
        if(retcode==200){
            NSLog(@"SDK初始化成功 %d",[weakSelf.zyOpenSdk  isSDKLogin]);
            result=[NSString stringWithFormat:@"SDK启动成功"];
        }else{
            result=[NSString stringWithFormat:@"SDK启动失败"];//后续SDK接口无法正常使用
        }
        NSString *log=[NSString stringWithFormat:@"initSDK[tenantId=%d, appToken=%@] retcode=%d ,err=%@  %@,lastTime=%@",tenantId,appToken,retcode,errDescription,uToken.token,uToken.lastLoginTime ] ;
        [weakSelf updateLogsText:log];
        [weakSelf updateLogsText: result];
        
    }];
}



//SDK 功能代码示例
- (IBAction)clickSendEvent:(id)sender {
    UIButton *btn=(UIButton *)sender;
    NSInteger tag= btn.tag;
    NSString *ret=nil;
    NSString *str=nil;
    _devTypeId=_edtDevTypeId.text ;
    NSString *targetKeyhash=self.edtTargetKeyhash.text;//targetKeyhash是指定设备的keyhash
    
    
    if(tag==-1){//init sdk
        [self initSDKWithTenantd:[_edtTenantId.text intValue] appToken:_edtAppToken.text];
        return;
    }
    
//    [self.zyOpenSdk openSetUserInfoWithMsgSwitch:@"true" pushSwitch:@"true" emailSwitch:@"1" wechatSwitch:@"true" phonePush:@"ios_0" channelId:@"cid" noDisturbTime:@"660-6600" headProtrait:nil ring:@"ring" language:@"lang" fontSize:@"34" personalInfo:@"info" completion:^(int retcode, NSString *errDescription) {
//        [self updateLogsText:[NSString stringWithFormat:@"set user=%d",retcode]];
//    }];
//    [self.zyOpenSdk getSceneListWithCompletion:^(NSMutableArray *devSceneInfos, int retcode, NSString *errDescription) {
//        [self updateLogsText:[NSString stringWithFormat:@" ret=%d,,err=%@,getScenList=%@",retcode,errDescription,devSceneInfos]];
//        NSLog(@"get Scenes=%@",devSceneInfos);
//    }];
//    [self.zyOpenSdk openGetUserInfoWithCompletion:^(ZYUser *user, int retcode, NSString *errDescription) {
//        [self updateLogsText:[NSString stringWithFormat:@"user=%@,%d,%d,%d,%d,%@,%@,%@,%@,%@,%d",user,user.emailSwitch,user.wechatSwitch,user.msgSwitch,user.pushSwitch,user.headProtrait,user.lastLoginWay,user.lastLoginTime,user.lastLoginPhoneType,user.noDisturbTime,user.fontSize]];
//    }];
//    [self.zyOpenSdk openWechatRemovePublicWithCompletion:^(int retcode, NSString *errDescription) {
//        [self updateLogsText:[NSString stringWithFormat:@"remove wechat pub retcode=%d,err=%@",retcode,errDescription]];
//    }];
//
//    [self.zyOpenSdk openGetUserListWithKeyhash:targetKeyhash completion:^(NSMutableArray *users, NSMutableArray *tempUsers, int retcode, NSString *errDescription) {
//        [self updateLogsText:[NSString stringWithFormat:@"getUserList retcode=%d,err=%@,%@,temps=%@",retcode,errDescription,users,tempUsers]];
//
//        NSLog(@"%d,getUsers=%@\n temp=%@",retcode,users,tempUsers);
//    } ];
//    long long now0=((long long)[[NSDate date] timeIntervalSince1970]);
//    NSString *time0=[NSString stringWithFormat:@"%lld-%lld",now0-6,now0+111060];
//    NSDictionary *dict0=[[NSDictionary alloc] initWithObjectsAndKeys:@"1",@"type",time0,@"time", nil];
//    NSError *error0;
//    NSData *jsonData0 = [NSJSONSerialization dataWithJSONObject:dict0 options:NSJSONWritingPrettyPrinted error:&error0];
//    NSString *jsonString0;
//    if (!jsonData0) {
//        NSLog(@"%@",error0);
//    }else{
//        jsonString0 = [[NSString alloc]initWithData:jsonData0 encoding:NSUTF8StringEncoding];
//    };
//    [self.zyOpenSdk shareTempUserWithKeyhash:targetKeyhash authority:nil  remark:@"test" completion:^(NSString *tempShareId, int retcode, NSString *errDescription) {
//        [self updateLogsText:[NSString stringWithFormat:@"shareTemp=%@ retcode=%d,err=%@",tempShareId,retcode,errDescription]];
//        [self.zyOpenSdk modifyTempUserWithTempShareId:tempShareId authority:jsonString0 remark:@"good" completion:^(int retcode, NSString *errDescription) {
//            [self updateLogsText:[NSString stringWithFormat:@"modifyTemp=%@ retcode=%d,err=%@",tempShareId,retcode,errDescription]];
//        }];
//    }];
    
   
//    [self.zyOpenSdk getDevLinkageListWithCompletion:^(NSMutableArray *devLinkages, int retcode, NSString *errDescription) {
//        NSLog(@"\n%d,getLinkages=%@\n",retcode,devLinkages);
//    }];
//    [self.zyOpenSdk getDevTriggerListWithCompletion:^(NSMutableArray *devTriggers, int retcode, NSString *errDescription) {
//        NSLog(@"%d,getTriggers=%@\n",retcode,devTriggers);
//
//    }];
//    [self.zyOpenSdk getDevTimedTaskWithKeyhash:targetKeyhash completion:^(NSMutableArray *devTimedTasks, int retcode, NSString *errDescription) {
//        NSLog(@"\n%d,getTimedTasks=%@",retcode,devTimedTasks);
//
//    }];
//    [self.zyOpenSdk getDevAttrListForNoGlobalWithKeyhash:targetKeyhash completion:^(DeviceInfoEntity *dev, int retcode, NSString *errDescription) {
//        NSLog(@"\n%d,getDevAttrNoglobal=%@",retcode,dev);
//
//    }];
//    [self.zyOpenSdk getDevCustomTriggerListWithKeyhash:targetKeyhash completion:^(NSMutableArray *devCustomerTriggers, int retcode, NSString *errDescription) {
//        NSLog(@"\n%d,getCustoemrTriggers=%@",retcode,devCustomerTriggers);
//    }];
//    NSString *jsonTest=@"{\"status\":true}";
//    NSData *jsonData = [jsonTest dataUsingEncoding:NSUTF8StringEncoding];
//    NSError *err;
//    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
//                                          options:NSJSONReadingMutableContainers
//                                            error:&err];
//    if(err)
//    {
//        NSLog(@"data parse exp[%@] data.length=%d",err.description,(int)jsonTest.length);
//    }
//    NSString *res=nil;//[NSString stringWithFormat:@"%@",[dic objectForKey:@"status"]];
//    NSLog(@"token=%@,%d,%@,,%d,%@",[_zyOpenSdk getZotToken],[res boolValue],res.class, [res isKindOfClass:NSString.class],[NSString stringWithFormat:@"%@",[dic objectForKey:@"status"]]);
////    [self.zyOpenSdk addDevCustomTriggerWithKeyhash:targetKeyhash attrName:@"statew" condition:@"{\"operation\":\"contains\",\"threshold\":\"1\"}" timeLimit:@"{\"type\":\"0\"}" status:@"true" remark:@"ago" completion:^(NSString *triggerId, int retcode, NSString *errDescription) {
////        NSLog(@"%d addDevCumTrigger=%@,err=%@",retcode,triggerId,errDescription);
////    }];
//    NSString *triggerId=@"5c12063024666436b09a8db9";
//        [self.zyOpenSdk modifyDevCustomTriggerWithTriggerId:triggerId  keyhash:targetKeyhash attrName:@"state" condition:@"{\"operation\":\"contains\",\"threshold\":\"test\"}" timeLimit:@"{\"type\":\"1\",\"time\":\"1000-36000\"}" status:@"on" remark:@"gooo" completion:^(int retcode, NSString *errDescription) {
//            NSLog(@"%d modifyDevCumTrigger=%@,err=%@",retcode,triggerId,errDescription);
//        }];
//
//    triggerId=@"5c11f1a6246664137f8c337f";
//    [self.zyOpenSdk deleteDevCustomTriggerWithTriggerId:triggerId completion:^(int retcode, NSString *errDescription) {
//        NSLog(@"%d deleteCumTrigger=%@",retcode,errDescription);
//    }];
//    triggerId=@"5c11f83cbdcb1e1a7026080b";
////    [self.zyOpenSdk setDevTriggerSwitchWithKeyhash:targetKeyhash triggerId:triggerId triggerSwitch:@"TRUE" completion:^(int retcode, NSString *errDescription) {
////        NSLog(@"%d=set triggerSwitch=%@",retcode,errDescription);
////    }];
//    NSArray *ids=[NSArray arrayWithObjects:triggerId,@"5c11f93824666436b09a8d8e", @"5c11f93824666436b09a8d8f",@"e", @"5c11f93824666436b09a8d90", @"5c11f93824666436b09a8d91",@"helkjh", @"5c11f93824666436b09a8d92", @"5c11f93824666436b09a8d93",@"5c11f93824666436b09a8d94",  nil];
//    ids=[NSArray arrayWithObjects:targetKeyhash,@"test1", @"test2",@"e", @"test3", @"test4",@"helkjh", @"test2", @"test1",@"test4",  nil];
//    for (int i=0; i<ids.count; i++) {
////        [self.zyOpenSdk getDevTriggerSwitchWithKeyhash:targetKeyhash triggerId:ids[i] completion:^(NSString *triggerId, NSString *triggerSwitch, int retcode, NSString *errDescription) {
////            NSLog(@"%d %d=get triggerSwitch.%@=%@",i,retcode,triggerId,triggerSwitch );
////        }];
////        [self.zyOpenSdk bindDevWithKeyhash:ids[i] devTypeId:_devTypeId completion:^(int retcode, NSString *errDescription) {
////            NSLog(@"%d %d=bindDev ",i,retcode );
////        }];
////        [self.zyOpenSdk getDevAttrListWithKeyhash:ids[i] completion:^(DeviceInfoEntity *dev, int retcode, NSString *errDescription) {
////            NSLog(@"%d %d=getDevInfo=%@",i,retcode,dev.keyhash );
////        }];
//    }
//    NSString *timeTaskId=@"5c130684d2446d5121177b16";
//    [self.zyOpenSdk addDevTimedTaskWithKeyhash:targetKeyhash time:[NSString stringWithFormat:@"%lld" ,now0+100] attrName:@"statew" attrValue:@"hello timed " repeat:nil remark:@"timed222" sceneId:nil completion:^(NSString *timedTaskId, int retcode, NSString *errDescription) {
//        NSLog(@"%d addTimedTask=%@",retcode,timedTaskId);
//    }];
//    [self.zyOpenSdk modifyDevTimedTaskWithTimedTaskId:timeTaskId keyhash:targetKeyhash time:@"32160" attrName:@"stater" attrValue:@"testTimedTask" repeat:@"145" remark:@"modify" sceneId:@"5c13081bd2446d5121177b18" completion:^(int retcode, NSString *errDescription) {
//        NSLog(@"%d modifyTimedTask=%@",retcode,errDescription);
//    }];
////    [self.zyOpenSdk deleteDevTimedTaskWithTimedTaskId:timeTaskId completion:^(int retcode, NSString *errDescription) {
////        NSLog(@"%d deleteTimedTask=%@",retcode,errDescription);
////    }];
//    NSString *linkageId=@"5c122f78d2446d5121177af6";
//    [self.zyOpenSdk addDevLinkageWithKeyhash:targetKeyhash attrName:@"statew" condition:@"{\"operation\":\"contains\",\"threshold\":\"hello\"}" keyhash2:targetKeyhash attrName2:@"stater" attrValue2:@"test link2" timeLimit:@"{\"type\":\"0\"}" remark:@"remakr" sceneId:nil completion:^(NSString *linkageId, int retcode, NSString *errDescription) {
//        NSLog(@"%d addLinkage=%@",retcode,linkageId);
//    }];
////    [self.zyOpenSdk modifyDevLinkageWithLinkageId:linkageId keyhash:targetKeyhash attrName:@"statew" condition:@"{\"operation\":\"contains\",\"threshold\":\"hell\"}" keyhash2:targetKeyhash attrName2:@"statew" attrValue2:@"test link3" timeLimit:@"{\"type\":\"1\",\"time\":\"0-1544746127\"}" remark:@"test link modify ." sceneId:nil completion:^(  int retcode, NSString *errDescription) {
////                NSLog(@"%d modifyLinkage",retcode);
////    }];
//    [self.zyOpenSdk deleteDevLinkageWithLinkageId:linkageId completion:^(int retcode, NSString *errDescription) {
//             NSLog(@"%d deleteLinkage",retcode);
//    }];
//
////    [self.zyOpenSdk addSceneWithSceneName:@"场景定时2" sceneType:@"0" remark:nil completion:^(NSString *sceneId, int retcode, NSString *errDescription) {
////        NSLog(@"%d add Scene=%@",retcode,sceneId);
////    }];
//    NSString *sceneId=@"5c13081bd2446d5121177b18";
//    [self.zyOpenSdk modifySceneWithSceneId:sceneId sceneName:@"场景呀" remark:@"备注" completion:^(int retcode, NSString *errDescription) {
//                NSLog(@"%d modify ",retcode);
//    }];
////    [self.zyOpenSdk devResetDevWithKeyhash:targetKeyhash completion:^(int retcode, NSString *errDescription) {
////        NSLog(@"reset dev=%d",retcode);
////    }];
//    [self.zyOpenSdk setDevPushSwitchWithKeyhash:targetKeyhash pushSwitch:@"false" emailSwitch:@"1" wechatSwitch:@"no" completion:^(int retcode, NSString *errDescription) {
//        NSLog(@"set dev switch=%d",retcode);
//    }];
//    [self.zyOpenSdk getDevLogsWithKeyhash:targetKeyhash timestamp1:@"0" timestamp2:@"0" limit:@"3" completion:^(NSMutableArray *devLogs, int retcode, NSString *errDescription) {
//        NSLog(@"%d getLogs=%@",retcode,(NSArray*)devLogs);
//    }];
//    [self.zyOpenSdk getDevAttrOperationWithDevTypeId:_devTypeId completion:^(NSMutableArray *attrOperations, int retcode, NSString *errDescription) {
//        NSLog(@"%d get属性定义=%@",retcode,attrOperations);
//    }];
//    [self.zyOpenSdk modifySceneWithSceneId:sceneId sceneName:@"修场景"  remark:nil completion:^(int retcode, NSString *errDescription) {
//        NSLog(@"modify scene=%d ",retcode );
//    }];
//    [self.zyOpenSdk getSceneInfoWithSceneId:sceneId completion:^(DeviceSceneInfo *scene, int retcode, NSString *errDescription) {
//        NSLog( @"%d getSceneInfo=%@, =%@",retcode,scene,scene.tasks);
//    }];
    //    Event是APP与设备进行通信的消息封装，包含设备属性名、属性值、属性值类型。
    NSString *attrName=self.edtEventAttrName.text;//发送Event与设备进行通信时指定的属性名
    int32_t attrType=[self.edtEventAttrType.text intValue];//指定属性值类型发送Event
    NSString *attrValue1=self.edtEventValue.text;//指定属性值类型为string时的属性值
    int32_t attrV2=[attrValue1 intValue];//指定属性值类型为int时的属性值
    int iotClientState= [self.zyOpenSdk getIOTClientState];//当前的IOT Client状态，当状态值为1或3时，可正常收发Event。
    NSString *logText=nil;
    [self updateLogsText:[NSString stringWithFormat:@"nowTimesecond=%lld ",(long long)[[NSDate date] timeIntervalSince1970]]];
    __weak typeof(self) weakSelf=self;
    if(tag==1) {
//        attrName=@"statew";
       logText=[NSString stringWithFormat:@"iotState=%d本次Event即将发送name=%@,attrType=string,value=%@,dev=%@",iotClientState,attrName,attrValue1,targetKeyhash];
        [self updateLogsText:logText];
        //APP发送Event到设备，属性值类型是String
        ret=[self.zyOpenSdk sendEventStrFromApp:10 attrName:attrName valueStr:attrValue1 targetKeyhash:targetKeyhash];
        [self updateLogsText: [NSString stringWithFormat:@"1-ret.sendEvent.App.str=%@  ",ret]];
//        [self.zyOpenSdk addSceneWithSceneName:@"测试中文1" sceneType:@"1" remark:@"测试1" completion:^(NSString *sceneId, int retcode, NSString *errDescription) {
//            NSLog(@"addScene %d err=%@, ID=%@",retcode,errDescription,sceneId);
//        }];
//        [weakSelf.zyOpenSdk getSceneListWithCompletion:^(NSMutableArray *devSceneInfos, int retcode, NSString *errDescription) {
//            if(retcode==200&&devSceneInfos.count>0){
//                NSString *name=((DeviceSceneInfo*)devSceneInfos[0]).name;
//                [weakSelf updateLogsText:name];
//                NSString *name2=[weakSelf replaceUnicode:name];
//                [weakSelf updateLogsText:[NSString stringWithFormat:@" ret=%d,,err=%@,getScenList=%@, %@ ,%@ ",retcode,errDescription,devSceneInfos,((DeviceSceneInfo*)devSceneInfos[0]).name,name2]];
//                weakSelf.edtEventValue.text= name;
//            }
//
//        }];
    }
   
    else if(tag==2) {//APP发送Event到设备，属性值类型是int
//        attrName=@"inttest";
        logText=[NSString stringWithFormat:@"iotState=%d本次Event即将发送name=%@,attrType=int,value=%d,dev=%@",iotClientState,attrName,attrV2,targetKeyhash];
        [self updateLogsText:logText];
        ret=[self.zyOpenSdk sendEventIntFromApp:2 attrName:attrName valueInt:attrV2 targetKeyhash:targetKeyhash];
        [self updateLogsText: [NSString stringWithFormat:@"2-ret.sendEvent.App.int=%@",ret]];
    }
    
    else if(tag==3) {//APP发送Event到设备，属性值类型是hex(如语音文件的NSData内容)
//        attrName=@"hextest";
        attrValue1=[NSString stringWithFormat:@"hexstr_%@",attrValue1];
        str=attrValue1;
        //这里是测试才用string，正常情况下发送hex语音文件数据内容而不是string转data数据
        NSData *data=[NSData dataWithData:[str dataUsingEncoding:NSUTF8StringEncoding]];
        //        Byte bs[6]={1,2,3,4,5,6};
        //        NSData *data=[NSData dataWithBytes:bs length:6];
        logText=[NSString stringWithFormat:@"iotState=%d本次Event即将发送name=%@,attrType=hex,value=%@,dev=%@",iotClientState,attrName,str,targetKeyhash];
        ret=[self.zyOpenSdk sendEventHexFromApp:3 attrName:@"hextest" valueHexBytes:data targetKeyhash:targetKeyhash];
        [self updateLogsText: [NSString stringWithFormat:@"3-ret.sendEvent.App.hex=%@,分片?hexLen=%d",ret,(int)data.length ]];
    }
    
    else if(tag==4) {//APP发送Event读取属性值，指定属性名读取对应的值（注意读取hex类型的属性的解析过程与string和int不一样）
        ret=[self.zyOpenSdk sendEventToReadDevAttrFromAPP:targetKeyhash attrName:attrName attrType:attrType];
        [self updateLogsText: [NSString stringWithFormat:@"(4)-ret.sendEvent.App.read[%@].type[%d]=%@",attrName,attrType,ret]];
    }
    //    不直接使用IOT的设备是子设备，对于APP来说子设备是APP直连子设备比如蓝牙设备，另外还有网关下挂的子设备
    else  if(tag==5) {//APP直连子设备发送Event到平台时target为空，发送给其他设备时target为对方keyhash
        if(![self.childOnlineDicInfo objectForKey:_childDevKeyhash]){
            //子设备发送event之前需要先登录。
            ret=[self.zyOpenSdk childDevLogin:@"bluetooth" childDevKeyhash:_childDevKeyhash];
            [self updateLogsText: [NSString stringWithFormat:@"(5-0)-ret.sendEvent.Child.login.[bluetooth]=%@",ret]];
        }
        if(targetKeyhash&&targetKeyhash.length==0){
            targetKeyhash=NULL;//要么为null，要么为对方keyhash(一般子设备通信时，target=null，因为一般只需要将子设备属性Event发送到平台更新，而不是子设备控制其他设备)。
        }
        NSData *data5=[NSData dataWithData:[attrValue1 dataUsingEncoding:NSUTF8StringEncoding]];
        ret=[self.zyOpenSdk sendEventFromChildDev:5 attrType:attrType attrName:attrName  valueStr:attrValue1 valueInt:attrV2 valueHex:data5 target:targetKeyhash childDevKeyhash:_childDevKeyhash];
        [self updateLogsText: [NSString stringWithFormat:@"5-ret.sendEvent.Child.any.type[%d]=%@[hexLen=%d]",attrType,ret,(int)data5.length]];
    }
    
    else if(tag==6) {//APP直连子设备发送Event读取属性值
        if(![self.childOnlineDicInfo objectForKey:_childDevKeyhash]){
            //子设备发送event之前需要先登录。
            ret=[self.zyOpenSdk childDevLogin:@"bluetooth" childDevKeyhash:_childDevKeyhash];
            [self updateLogsText: [NSString stringWithFormat:@"(5-0)-ret.sendEvent.Child.login.[bluetooth]=%@",ret]];
        }
        ret=[self.zyOpenSdk sendEventToReadDevAttrFromChildDev:targetKeyhash childDevKeyhash:_childDevKeyhash attrName:attrName attrType:attrType];
        [self updateLogsText: [NSString stringWithFormat:@"(6)-ret.sendEvent.Child[%@].read[%@].type[%d]=%@",_childDevKeyhash,attrName,attrType,ret]];
    }
    
    else if(tag==7) {
        //appToken对应的用户绑定设备（扫描设备二维码得到keyhash ,devTypeId），设备只允许一个用户绑定，绑定后用户是设备的管理员，level=1是一级用户。可以分享设备给其他用户，其他用户为二级用户，level=2.
        [self.zyOpenSdk bindDevWithKeyhash:targetKeyhash devTypeId:self.devTypeId completion:^(int retcode, NSString *errDescription) {
            if(retcode==200){
                NSLog(@"绑定设备成功");
            }
            [weakSelf updateLogsText:[NSString stringWithFormat:@"bindDev[%@:%@].retcode=%d,errText=%@",weakSelf.devTypeId,targetKeyhash,retcode,errDescription]];
        }];
        [self.zyOpenSdk openAuthorizeUserWithKeyhash:targetKeyhash authUserId:@"UID2" authority:nil remark:@"如用户名2" completion:^(int retcode, NSString *errDescription) {
            if(retcode==200){
                NSLog(@"2 设备授权分享给用户成功");
            }
            [weakSelf updateLogsText:[NSString stringWithFormat:@"authUsertoDev2 .retcode=%d,errText=%@",retcode,errDescription]];
            [weakSelf.zyOpenSdk openModifyAuthUserWithKeyhash:targetKeyhash authUserId:@"UID2" authority:@"{\"type\":\"2\",\"time\":\"0-44011\",\"week\":\"45\"}" remark:@"运输" completion:^(int retcode, NSString *errDescription) {
                
                NSLog(@" 设备modify分享给用户成功 %d",retcode);
            }];
        }];
    }
    else if(tag==8) {
        [self.zyOpenSdk openUnAuthorizeUserWithKeyhash:targetKeyhash authUserId:@"UID2" completion:^(int retcode, NSString *errDescription) {
            if(retcode==200){
                NSLog(@"删除二级用户成功2");
            }
            [weakSelf updateLogsText:[NSString stringWithFormat:@"2 deleteAuthUser .retcode=%d,errText=%@",retcode,errDescription]];
        }];
        [self.zyOpenSdk openUnAuthorizeUserWithKeyhash:targetKeyhash authUserId:@"UID3" completion:^(int retcode, NSString *errDescription) {
            if(retcode==200){
                NSLog(@"删除二级用户成功3");
            }
            [weakSelf updateLogsText:[NSString stringWithFormat:@"3 deleteAuthUser .retcode=%d,errText=%@",retcode,errDescription]];
        }];
        
        long long now=((long long)[[NSDate date] timeIntervalSince1970]);
        NSString *time=[NSString stringWithFormat:@"%lld-%lld",now-6,now+160];
        NSDictionary *dict=[[NSDictionary alloc] initWithObjectsAndKeys:@"1",@"type",time,@"time" , nil];
        NSError *error;
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&error];
        NSString *jsonString;
        if (!jsonData) {
            NSLog(@"%@",error);
        }else{
            jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
        };
        //appToken对应的用户将设备授权分享给其他用户（此时被分享的用户就是指定设备的二级用户），指定设备targetKeyhash然后将设备分享给指定的第三方用户authUserId（第三方用户ID），authority为空时表示全时访问即每一天每时刻都可以控制设备（具体其他权限详见API ZYOpenAccountSDK.h接口文档），remark是备注内容可以是昵称。
        [self.zyOpenSdk openAuthorizeUserWithKeyhash:targetKeyhash authUserId:@"UID2" authority:jsonString remark:@"如用户名2" completion:^(int retcode, NSString *errDescription) {
            if(retcode==200){
                NSLog(@"2 设备授权分享给用户成功");
            }
            [weakSelf updateLogsText:[NSString stringWithFormat:@"authUsertoDev2 .retcode=%d,errText=%@",retcode,errDescription]];
        }];
         time=[NSString stringWithFormat:@"%lld-%lld",now-60,now+66600];
         dict=[[NSDictionary alloc] initWithObjectsAndKeys:@"1",@"type",time,@"time" , nil];
         jsonData = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&error];
        if (!jsonData) {
            NSLog(@"%@",error);
        }else{
            jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
        };
        [self.zyOpenSdk openAuthorizeUserWithKeyhash:targetKeyhash authUserId:@"UID3" authority:jsonString remark:@"如用户名3" completion:^(int retcode, NSString *errDescription) {
            if(retcode==200){
                NSLog(@"3 设备授权分享给用户成功");
            }
            [weakSelf updateLogsText:[NSString stringWithFormat:@"authUsertoDev3 .retcode=%d,errText=%@",retcode,errDescription]];
        }];
        /**
         //appToken对应的用户编辑二级用户权限（此时被分享的用户就是指定设备的二级用户），指定设备targetKeyhash，然后修改设备分享给指定的第三方用户authUserId（第三方用户ID）的权限，authority为空时表示全时访问即每一天每时刻都可以控制设备（具体其他权限详见API ZYOpenAccountSDK.h接口文档），remark是备注内容可以是昵称。
         [self.zyOpenSdk openModifyAuthUserWithKeyhash:targetKeyhash authUserId:@"yours authUserId" authority:@"json authority value" remark:@"remark" completion:^(int retcode, NSString *errDescription) {
         if(retcode==200){
         NSLog(@"编辑二级用户权限成功");
         }
         [weakSelf updateLogsText:[NSString stringWithFormat:@"modifyAuthUser .retcode=%d,errText=%@",retcode,errDescription]];
         }];
         //appToken对应用户删除二级用户分享，按照指定设备targetKeyhash和第三方用户authUserId（第三方用户ID），可以删除设备的authUserId用户对targetKeyhash设备的控制权，即删除二级用户。
         [self.zyOpenSdk openUnAuthorizeUserWithKeyhash:targetKeyhash authUserId:@"yours authUserId" completion:^(int retcode, NSString *errDescription) {
         if(retcode==200){
         NSLog(@"删除二级用户成功");
         }
         [weakSelf updateLogsText:[NSString stringWithFormat:@"deleteAuthUser .retcode=%d,errText=%@",retcode,errDescription]];
         }];
         */
    }
    
    else if(tag==9) {
        //用户删除设备，根据指定targetKeyhash设备，可以删除设备，删除后将无法控制设备。一级用户（管理员）删除设备将连带删除设备下的所有用户(包括二级用户和临时用户),二级用户删除设备则只是自己失去设备控制权限。
        [self.zyOpenSdk deleteDeviceWithKeyhash:targetKeyhash completion:^(int retcode, NSString *errDescription) {
            if(retcode==200){
                NSLog(@"用户删除设备成功");
            }
            [weakSelf updateLogsText:[NSString stringWithFormat:@"deleteDev .retcode=%d,errText=%@",retcode,errDescription]];
        }];
    }
    
    else if(tag==10) {
        //获取appToken对应用户的设备列表，含一些特定属性，如在线状态、设备名称等
        [self.zyOpenSdk getDevListWithSomeAttrsWithCompletion:^(NSMutableArray *devs, int retcode, NSString *errDescription) {
            if(retcode==200){
                NSLog(@"获取设备列表成功， devs=%@",devs);
            }
            [weakSelf updateLogsText:[NSString stringWithFormat:@"getDevsWithAttrs .retcode=%d,devs=%@,errText=%@",retcode,devs,errDescription]];
        }];
        
        //appToken对应用户获取appToken对应用户的设备列表，不含任何属性值
        [self.zyOpenSdk getDevListWithCompletion:^(NSMutableArray *devs, int retcode, NSString *errDescription) {
            if(retcode==200){
                NSLog(@"获取设备列表成功， devs=%@",devs);
            }
            [weakSelf updateLogsText:[NSString stringWithFormat:@"getDevs .retcode=%d,devs=%@,errText=%@",retcode,devs,errDescription]];
        }];
    }
    else if(tag==11) {
        //appToken对应的用户获取指定设备的所有属性值，targetKeyhash是指定设备的keyhash
        [self.zyOpenSdk getDevAttrListWithKeyhash:targetKeyhash completion:^(DeviceInfoEntity *dev, int retcode, NSString *errDescription) {
            if(retcode==200){
                NSLog(@"获取设备属性all值成功 ，devInfo=%@",dev);
            }
            [weakSelf updateLogsText:[NSString stringWithFormat:@"getDevAttrs .retcode=%d,devs=%@,errText=%@",retcode,dev,errDescription]];
        }];
    }
    else if(tag==12) {
        //appToken对应的用户检测设备版本是否需要升级
        ZYFotaAPI *devFotaApi=[ZYFotaAPI getFotaInstance];//初始化接口实例
        if([devFotaApi connectStatus]!=1){//调用接口前定要先判断连接Fota的状态
            [devFotaApi openConnection];
        }
        NSLog(@"fota connectStatus=%d",[devFotaApi connectStatus]);
        //指定设备targetKeyhash进行检测是否升级，并指定结果回调接口
        [devFotaApi setDevUpdateWithDelegate:self keyhash:targetKeyhash];
        [devFotaApi checkDevUpdateVersion];//检测设备版本
        
    }
    
    
}

- (IBAction)clickToConnect:(id)sender {
    //需要与设备进行通信时，若getIOTClientState值不是1或3，可以选择以下接口手动启动IOT Client。
    [self.zyOpenSdk toASyncStartOrStopIOTClient:1];
}

- (IBAction)clickToDisConnect:(id)sender {
    //不需要与设备进行通信时可以暂时断开IOT Client
    [self.zyOpenSdk toASyncStartOrStopIOTClient:2];
}

- (IBAction)clickToDisConnectOver:(id)sender {
    //彻底不需要与设备进行通信时可以彻底断开IOT Client，如退出APP时
    [self.zyOpenSdk toASyncStartOrStopIOTClient:2];
}

#pragma mark->SDK Login manager delegate
-(void) sdkLoginSuccess{
    [self updateLogsText:@"SDK Login success"];
}

-(void) sdkLoginFailure:(int)retcode err:(NSString *)errDescription{
    [self updateLogsText:[NSString stringWithFormat:@"SDK失效，%d=%@",retcode,errDescription]];
}

#pragma mark ->ZYIOT manager delegate start.

#pragma mark MyEventResponseDelegate
/**
 接收到一个event消息，此时Event接收方是APP。ZY平台主动下发event时source无值。
 @param event 消息封装，包含设备属性名、属性值等
 @param source 发出Event的一方，指的是设备keyhash或null(平台)。如设备状态变更时发送Event通知APP，此时source是设备keyhash.
 */
-(void)onEventForAPP:(MyEventData *)event fromSource:(NSString *)source  {
    int32_t eventId=event.eventId;//消息ID，可在发送Event时指定eventId
    int16_t attrType=event.attrType;//属性值的类型，根据不同的属性值类型解析不同的value字段，得到属性值。如type=1时，attrValue1为属性值。
    NSString *attrName=event.attrName;//属性名
    if([@"hextest" isEqual:attrName]){
        //读取hex类型的属性时，attrName=attrName，type=1，返回的是hex文件ID列表(形如objectId_timestamp,objectId_timestamp)。然后将文件ID列表中的objectId值作为attrName(此时type=4)依次发送event去获取文件内容。
        NSString *ids=event.attrValue1;
        if(ids){//hex类型的属性，允许有多个值，所以会有多个文件（string和int类型的属性，只有一个值）
            NSArray *fileIdStrs=[ids componentsSeparatedByString:@","];
            NSLog(@"fileIdStrs=%@",fileIdStrs);
            if(fileIdStrs&&fileIdStrs.count>0){
                int len=(int)fileIdStrs.count;
                for(int i=0;i<len;i++){
                    NSString *fileIdStr=fileIdStrs[i];
                    NSArray *infos=[fileIdStr componentsSeparatedByString:@"_"];
                    if(infos&&infos.count>0){
                        NSString *fileId=infos[0];//依次读取fileId对应的hex文件内容（文件太大时会分片后发送多个Event，记得组合后才是一个属性值）
                        [self.zyOpenSdk sendEventToReadDevAttrFromAPP:source attrName:fileId attrType:4];
                    }
                }
            }
        }
    }
    
    if(attrType==4){//属性值类型为4，表示此时Event封装的属性值是NSData类型，表示可能被分片传输，组合后才是完整的苏属性值
        //       当前分片从1开始计数。 若当前分片等于总片数则表示没有分片，则本属性值就是本Event的attrValue3。
        int16_t currentFrame=event.currentFrame;//当前分片，表示分片传输时，本Event的位置是第几片
        int16_t totalFrame=event.totalFrames;//总片数，表示分片传输时，一个hex文件属性值被分为几片
        //        将属性名和eventId作为组合分片数据内容时的标识键
        NSString *keyEvent =[NSString stringWithFormat:@"%@%d",attrName,eventId];
        NSMutableArray *datas=nil;
        if([self.valuesHexMap objectForKey:keyEvent]){//如果已经有接收到本属性名对应的分片
            datas=[self.valuesHexMap objectForKey:keyEvent];
            if(currentFrame==1 ){//一旦当前片数为1，则之前接收的相同属性标识键对应的分片数据需要清零，因为已经失效。（后台只允许一次发送一组分片数据——分片从1开始计数，不会许乱序发送）
                [self updateLogsText:[NSString stringWithFormat:@"%@[%d]=重新接收",attrName,eventId]];
                [datas removeAllObjects];
            }
            [datas addObject:event.attrValue3 ];//将本片数据暂时存储，以便在接收完所有分片后合并为属性值
        }else{
            datas=[[NSMutableArray alloc] init];
            [datas addObject:event.attrValue3 ];//将本片数据暂时存储，以便在接收完所有分片后合并为属性值
        }
        
        if(currentFrame==totalFrame){//当前分片与总片数相等，则表示所有分片接收完毕
            NSMutableData *data=[[NSMutableData alloc] init];
            for(int i=0;i<totalFrame;i++){ //在接收完所有分片后合并为属性值
                [data appendData:datas[i] ];
            }
            
            //data就是所有分片组合后得到的那个属性值（我测试时发送的是String内容，所以接下来打印出来）
            NSString *result=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            
            [self updateLogsText:[NSString stringWithFormat:@"%@[%d]={total=%d}接收到的分片Hex转为字符串为=%@",attrName,eventId,totalFrame,result]];
            if(data.length<6){
                [self updateLogsText:[NSString stringWithFormat:@"datas=[%@]",datas]];
            }
            [self.valuesHexMap removeObjectForKey:keyEvent];
        }else{
            [self.valuesHexMap setObject:datas forKey:keyEvent];
        }
    }
    [self updateLogsText:[NSString stringWithFormat:@"\t收到 [source=%@] Event回调=%@ ,frame[%d:%d]",source,event,event.totalFrames,event.currentFrame] ];
}

/**接收到一个event消息，此时接收方是app的直连子设备(不直接使用IOT的设备是子设备，对于APP来说子设备是APP直连子设备比如蓝牙设备，另外还有网关下挂的子设备)。监听到本event需要将值再发送给对应的子设备。
 @param event Event消息封装，包含设备属性名、属性值等
 @param source 发出这个Event的一方（表示对应的设备ID或null）
 @param childDevKeyhash 子设备ID（表示需要将这个Event的属性值再发给对应的子设备），如现用户的设备列表有一个蓝牙子设备C，此时接收到本Event[attrName=statew,type=1,attrValue1=2]且childDevKeyhash=C，那么APP通过蓝牙为C设备设置statew值为2。
 */
- (void)onEventForChildDev:(MyEventData *)event fromSource:(NSString *)source toChildDevKeyhash:(NSString *)childDevKeyhash{
    int32_t eventId=event.eventId;
    int16_t attrType=event.attrType;
    NSString *attrName=event.attrName;
    
    if([@"hextest" isEqual:attrName]){
        NSString *ids=event.attrValue1;
        if(ids){
            NSArray *fileIdStrs=[ids componentsSeparatedByString:@","];
            NSLog(@"fileIdStrs=%@",fileIdStrs);
            if(fileIdStrs&&fileIdStrs.count>0){
                int len=(int)fileIdStrs.count;
                for(int i=0;i<len;i++){
                    NSString *fileIdStr=fileIdStrs[i];
                    NSArray *infos=[fileIdStr componentsSeparatedByString:@"_"];
                    if(infos&&infos.count>0){
                        NSString *fileId=infos[0];
                        [self.zyOpenSdk sendEventToReadDevAttrFromAPP:source attrName:fileId attrType:4];
                    }
                }
            }
        }
    }
    
    if(attrType==4){
        int16_t currentFrame=event.currentFrame;
        int16_t totalFrame=event.totalFrames;
        NSString *keyEvent =[NSString stringWithFormat:@"%@%d",attrName,eventId];
        NSMutableArray *datas=nil;
        if([self.valuesHexMap objectForKey:keyEvent]){
            datas=[self.valuesHexMap objectForKey:keyEvent];
            if(currentFrame==1 ){
                [self updateLogsText:[NSString stringWithFormat:@"%@[%d]=重新接收",attrName,eventId]];
                [datas removeAllObjects];
            }
            [datas addObject:event.attrValue3];
        }else{
            datas=[[NSMutableArray alloc] init];
            [datas addObject:event.attrValue3];
        }
        
        if(currentFrame==totalFrame){
            NSMutableData *data=[[NSMutableData alloc] init];
            for(int i=0;i<totalFrame;i++){
                [data appendData:datas[i] ];
            }
            NSString *result=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            
            [self updateLogsText:[NSString stringWithFormat:@"%@[%d]={total=%d}接收到的分片Hex转为字符串为=%@ ",attrName,eventId,totalFrame,result]];
            if(data.length<6){
                [self updateLogsText:[NSString stringWithFormat:@"datas=[%@]",datas]];
            }
            [self.valuesHexMap removeObjectForKey:keyEvent];
        }else{
            [self.valuesHexMap setObject:datas forKey:keyEvent];
        }
    }
    [self updateLogsText:[NSString stringWithFormat:@"\t收到  chil Dev[source=%@] Event回调=%@ ,frame[%d:%d]",source,event,event.totalFrames,event.currentFrame] ];
}

/**
 event发送结果的回调
 @param isSuccess true表示成功发送到IOT服务器，false表示失败
 @param eventId 发送Event时指定的或返回的消息ID
 */
-(void)onEventSyncResponseWithStatus:(BOOL)isSuccess eventId:(int32_t)eventId{
    [self updateLogsText:[NSString stringWithFormat:@"\t已发送eventId=[%d]=%d ",eventId,isSuccess]];
}

/**子设备登录和退出登录时的结果回调
 @param loginResult 登录或退出登录的结果
 @param isLogin 表示登录或退出登录，true表示登录，false表示退出登录。
 @param childDevKeyhash 是这个子设备的登录（退出登录）
 @param childDevType 本子设备的类型（如蓝牙或串口，分别是bluetooth和com，都是小写字母）
 */
-(void)onEventForChildDevLoginOrOut:(BOOL)loginResult isLogin:(BOOL)isLogin childDevKeyhash:(NSString *)childDevKeyhash childDevType:(NSString *)childDevType{
    if(isLogin){
        [self.childOnlineDicInfo setObject:@"1" forKey:childDevKeyhash];
    }else{
        [self.childOnlineDicInfo removeObjectForKey:childDevKeyhash];
    }
    [self updateLogsText:[NSString stringWithFormat:@"\t收到 child login or out回调 dev=%@,loginResult=%d,isLogin=%d,devType=%@  ",childDevKeyhash,loginResult,isLogin,childDevType ]];
}
//发送event后，接收event失败。eventId是消息ID，发送event时可以指定
-(void)onEventFailureWithEventId:(int32_t)eventId{
    [self updateLogsText:[NSString stringWithFormat:@"\tevent failure=%d",eventId]];
}

#pragma mark IOTOnlineDelegate
- (void)onIOTConnect{//IOT 连接成功时回调
    NSLog(@"IOT Connect");
    [self updateLogsText:[NSString stringWithFormat:@" ZYIOT Connect now=%ld" ,(long)[[NSDate date] timeIntervalSince1970]]];
}

- (void)onIOTDisConnect{//IOT 异常断开时回调
    NSLog(@"IOT DisConnect");
   [self updateLogsText:[NSString stringWithFormat:@" ZYIOT DisConnect now=%ld" ,(long)[[NSDate date] timeIntervalSince1970]]];
}

#pragma mark ZYIOTClientStateDelegate
-(void)onStopped{//IOT被手动stop时回调
    NSLog(@"IOT stop.");
}
-(void)onStarted{//IOT被手动start时回调，表示正在start
    NSLog(@"IOT start.");
}
-(void)onResume{//IOT被手动resume时回调
    NSLog(@"IOT resume.");
}
-(void)onPaused{//IOT被手动pause时回调
    NSLog(@"IOT pause.");
}

#pragma mark -->ZYIOT manager delegate end.

#pragma Fota delegate (retcode==1 is ok)
/**获取设备固件升级进度
 @param retcode retcode=1时成功，其余数字表示失败
 @param keyhash keyhash fota模块当前keyhash
 @param isNewest isNewest true表示本设备已经是最新的设备
 @param isForceUpdate 本设备固件的当前版本若不是最新版本，固件不升级是否可用。true表示固件不升级就无法正常使用。
 @param currentV 本设备的当前版本
 @param newestV 本设备对应的最新的设备固件
 */
- (void)callCheckDevUpdateWithRetcode:(int16_t)retcode keyhash:(NSString *)keyhash isNewest:(BOOL)isNewest isForceUpdate:(BOOL)isForceUpdate currentVer:(NSString *)currentV newestVer:(NSString *)newestV {
    NSLog(@"升级时回调 retcode=%d, isNewest=%d isForce=%d, keyhash=%@",retcode,isNewest,isForceUpdate,keyhash);
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self updateLogsText:[NSString stringWithFormat:@"fota.getVersion.code=%d,isNewest=%d,keyhash=%@",retcode,isNewest,keyhash]];
    });
    
    if(retcode==1){//成功获取版本信息
        if(isNewest==NO)
        {
            NSString *result=[[ZYFotaAPI getFotaInstance] setDevUpdateStart];//通知设备升级（是通过Event通知设备升级的，由SDK内部发送消息） 
            NSLog(@"result=%@",result);
            if([result intValue]!=0){//发出升级命令
                [[ZYFotaAPI getFotaInstance] getDevUpdateProgress];//获取设备升级进度（通知设备升级成功后，才有进度值）
            }
        }
    }
}

/**获取设备固件升级进度
 @param retcode retcode=1时成功，其余数字表示失败
 @param keyhash keyhash fota模块当前keyhash
 @param progress 设备固件升级的进度
 */
- (void)callGetDevUpdateProgressWithRetcode:(int16_t)retcode keyhash:(NSString *)keyhash progress:(int)progress {
    NSLog(@"percentage升级时回调进度 retcode=%d, keyhash=%@ per=%d",retcode,keyhash,progress);
    if(retcode==1){//成功获取版本升级进度
        //continue get progress ? 如果需要持续接收进度，可以继续调用获取进度的接口
        if(progress!=100){
            NSLog(@"继续获取进度");
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [[ZYFotaAPI getFotaInstance] getDevUpdateProgress];
            });
        }
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        [self updateLogsText:[NSString stringWithFormat:@"fota.getProgress.code=%d,progress=%d,keyhash=%@",retcode,progress,keyhash]];
    });
    
    
}

//连接Fota模块断开
- (void)onCloseConnectToFota {
    NSLog(@"检测升级结束-----");
}

#pragma Fota delegate end













@end

