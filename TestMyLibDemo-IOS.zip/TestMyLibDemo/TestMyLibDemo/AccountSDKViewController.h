//
//  AccountSDKViewController.h
//  TestMyLibDemo
//
//  Created by ZY on 2019/6/25.
//  Copyright © 2019 zy-cxm. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AccountSDKViewController : UIViewController

-(void)updateLogsText:(NSString *)log;
@end

NS_ASSUME_NONNULL_END
