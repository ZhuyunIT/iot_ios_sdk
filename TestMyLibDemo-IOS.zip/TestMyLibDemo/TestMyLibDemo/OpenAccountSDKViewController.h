//
//  OpenAccountSDKViewController.h
//  TestMyLibDemo
//
//  Created by zy-cxm on 2018/10/22.
//  Copyright © 2018 zy-cxm. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface OpenAccountSDKViewController : UIViewController

-(void)updateLogsText:(NSString *)log;
@end

NS_ASSUME_NONNULL_END
