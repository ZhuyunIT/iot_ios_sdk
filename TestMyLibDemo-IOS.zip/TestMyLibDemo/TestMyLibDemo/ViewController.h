//
//  ViewController.h
//  KaaSdkDemo_2_2
//
//  Created by zy-cxm on 2018/10/22.
//  Copyright © 2018年 zy-cxm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

-(void)updateLogsText:(NSString *)log;
@end

